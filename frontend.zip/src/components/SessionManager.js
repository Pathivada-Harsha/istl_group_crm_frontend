// src/components/SessionManager.jsx
import { useEffect, useState, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import SessionTimeoutModal from "./SessionTimeoutModal";

export default function SessionManager() {
  const { logout, sessionTimeout, warningTime } = useAuth();
  const navigate = useNavigate();

  const SESSION_LIMIT = sessionTimeout || 15 * 60;
  const WARNING_AT = warningTime || 60;

  const [secondsLeft, setSecondsLeft] = useState(SESSION_LIMIT);
  const [showPopup, setShowPopup] = useState(false);

  // Refs — don't cause re-renders, safe across async boundaries
  const isPingingRef = useRef(false);     // true while ping fetch is in-flight
  const hasLoggedOutRef = useRef(false);  // prevents double-logout
  const showPopupRef = useRef(false);     // mirrors showPopup for event listeners

  // Keep showPopupRef in sync
  useEffect(() => {
    showPopupRef.current = showPopup;
  }, [showPopup]);

  // ── Logout (stable reference via useCallback) ──────────────────────────────
  const handleLogout = useCallback(() => {
    if (hasLoggedOutRef.current) return;   // ← guard: only logout once
    hasLoggedOutRef.current = true;
    logout();
    navigate("/login", { replace: true });
  }, [logout, navigate]);

  // ── Reset timer ────────────────────────────────────────────────────────────
  const resetTimer = useCallback(() => {
    setSecondsLeft(SESSION_LIMIT);
    setShowPopup(false);
    showPopupRef.current = false;
  }, [SESSION_LIMIT]);

  // ── Activity listener (only while popup is NOT visible) ───────────────────
  // No secondsLeft in deps → listener doesn't re-register every second
  useEffect(() => {
    const events = ["mousedown", "keydown", "scroll", "touchstart"];

    const handleActivity = () => {
      if (!showPopupRef.current) {
        resetTimer();
      }
    };

    events.forEach((e) =>
      window.addEventListener(e, handleActivity, { passive: true })
    );
    return () =>
      events.forEach((e) => window.removeEventListener(e, handleActivity));
  }, [resetTimer]); // ← resetTimer is stable (useCallback), safe single dep

  // ── Countdown (runs once, never clears) ───────────────────────────────────
  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsLeft((prev) => (prev <= 1 ? 0 : prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // ── Warning popup + auto-logout ────────────────────────────────────────────
  useEffect(() => {
    if (secondsLeft === WARNING_AT && !showPopup) {
      setShowPopup(true);
      showPopupRef.current = true;
    }

    if (secondsLeft <= 0 && !isPingingRef.current) {
      // ← Only logout if we are NOT mid-ping (user already clicked Stay)
      handleLogout();
    }
  }, [secondsLeft, showPopup, WARNING_AT, handleLogout]);

  // ── Backend fires session-expired event ───────────────────────────────────
  useEffect(() => {
    const handler = () => handleLogout();
    window.addEventListener("session-expired", handler);
    return () => window.removeEventListener("session-expired", handler);
  }, [handleLogout]); // ← handleLogout now stable, so this never re-registers needlessly

  // ── Stay active ───────────────────────────────────────────────────────────
  const handleStayActive = async () => {
    if (isPingingRef.current) return; // ← debounce: ignore double-clicks
    isPingingRef.current = true;

    // ✅ KEY FIX: Optimistic reset BEFORE the async ping.
    // Immediately reset the counter and hide the modal so the countdown
    // cannot hit 0 while the fetch is in-flight.
    resetTimer();

    try {
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/login/ping`,
        { method: "GET", credentials: "include" }
      );

      if (!response.ok) {
        // Server explicitly rejected — session really is gone
        handleLogout();
      }
      // If ok: timer is already reset above — nothing more to do ✓
    } catch (err) {
      console.error("Ping failed:", err);
      handleLogout();
    } finally {
      isPingingRef.current = false;
    }
  };

  return (
    <>
      {showPopup && (
        <SessionTimeoutModal
          seconds={secondsLeft}
          onStay={handleStayActive}
          onLogout={handleLogout}
        />
      )}
    </>
  );
}