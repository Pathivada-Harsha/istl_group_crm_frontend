/**
 * CRMAssistantBot.js  (v2 — backend-integrated)
 * ──────────────────────────────────────────────────────────────────────────────
 * Floating AI chat assistant for the ISTL CRM.
 *
 * HOW IT WORKS NOW
 *   - The frontend NO LONGER calls the Claude API directly.
 *   - The frontend NO LONGER fetches CRM data itself.
 *   - On every message, it sends the conversation history to:
 *       POST /api/ai-assistant/chat
 *   - The Spring Boot backend (AiAssistantService) handles:
 *       • Fetching live CRM data from its own services
 *       • Calling Claude with the API key stored in application.properties
 *       • Returning just the reply text
 *
 * INTEGRATION (3 steps — same as before)
 *   1. Copy this file  → src/components/CRMAssistantBot.js
 *   2. Copy the CSS    → src/components_css/CRMAssistantBot.css
 *   3. In App.js AppShell, after <SessionManager />:
 *        import CRMAssistantBot from './components/CRMAssistantBot';
 *        {!hideShell && <CRMAssistantBot />}
 * ──────────────────────────────────────────────────────────────────────────────
 */

import React, {
  useState,
  useRef,
  useEffect,
  useCallback,
} from 'react';
import { useAuth } from '../hooks/useAuth';
import '../components_css/CRMAssistantBot.css';

const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8080';

// ─── Helpers ──────────────────────────────────────────────────────────────────
function formatTime(date) {
  return date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
}

function renderText(text) {
  return text.split('\n').map((line, i, arr) => {
    const parts = line.split(/\*\*(.*?)\*\*/g);
    const nodes = parts.map((p, j) =>
      j % 2 === 1 ? <strong key={j}>{p}</strong> : p
    );
    return (
      <span key={i}>
        {nodes}
        {i < arr.length - 1 && <br />}
      </span>
    );
  });
}

const ROLE_COLORS = {
  SUPERADMIN:    '#7c3aed',
  ADMIN:         '#2563eb',
  BD_MANAGER:    '#10b981',
  SALES_MANAGER: '#10b981',
  BD_EXECUTIVE:  '#f59e0b',
  SALES_EXEC:    '#f59e0b',
  TELECALLER:    '#6b7280',
};
const roleColor = (role) => ROLE_COLORS[role?.toUpperCase()] || '#6b7280';

const SUGGESTIONS = {
  SUPERADMIN:    ['Show all users', 'How many active users?', 'Show inactive users', 'Recent users'],
  ADMIN:         ['Show all users', 'How many active users?', 'Show inactive users', 'Recent users'],
  BD_MANAGER:    ['Show hot leads', "List my team's leads", 'How many leads this month?', 'Show customers'],
  SALES_MANAGER: ['Show hot leads', "List my team's leads", 'How many leads this month?', 'Show customers'],
  BD_EXECUTIVE:  ['Show my leads', 'Any follow-ups due today?', 'Show warm leads'],
  SALES_EXEC:    ['Show my leads', 'Any follow-ups due today?', 'Show warm leads'],
  TELECALLER:    ['Show my assigned leads', 'Any follow-ups due today?'],
};
const getSuggestions = (role) =>
  SUGGESTIONS[role?.toUpperCase()] || ['What can you help me with?'];

// ─── Component ────────────────────────────────────────────────────────────────
export default function CRMAssistantBot() {
  const { user, menuPermissions, isAuthenticated } = useAuth();

  const [open,     setOpen]     = useState(false);
  const [messages, setMessages] = useState([]);
  const [input,    setInput]    = useState('');
  const [loading,  setLoading]  = useState(false);

  // Keeps the clean conversation (role + content) to send to the backend
  // Does NOT include assistant greeting messages (those are UI-only)
  const conversationRef = useRef([]);

  const bottomRef = useRef(null);
  const inputRef  = useRef(null);

  // ── Scroll to bottom ───────────────────────────────────────────────────────
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  // ── Focus input when panel opens ───────────────────────────────────────────
  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 120);
  }, [open]);

  // ── Greeting on first open ─────────────────────────────────────────────────
  const initialized = useRef(false);
  useEffect(() => {
    if (!open || initialized.current || !user) return;
    initialized.current = true;
    conversationRef.current = [];
    setMessages([
      {
        role: 'assistant',
        text: `Hello, **${user.name}** 👋\n\nI'm your CRM assistant. I have live access to your data — ask me anything!`,
        time: new Date(),
      },
    ]);
  }, [open, user]);

  // ── Send message ───────────────────────────────────────────────────────────
  const sendMessage = useCallback(async (text) => {
    const userText = (text || input).trim();
    if (!userText || loading) return;
    setInput('');

    // Add to UI
    const userMsg = { role: 'user', text: userText, time: new Date() };
    setMessages(prev => [...prev, userMsg]);

    // Add to clean conversation history for backend
    conversationRef.current = [
      ...conversationRef.current,
      { role: 'user', content: userText },
    ];

    setLoading(true);

    try {
      const res = await fetch(`${API_BASE}/ai-assistant/chat`, {
        method: 'POST',
        credentials: 'include',          // sends session cookie — backend validates it
        headers: {
          'Content-Type': 'application/json',
          'User-Id':   String(user.id),
          'User-Role': String(user.role),
        },
        body: JSON.stringify({
          messages: conversationRef.current,
        }),
      });

      if (res.status === 401) {
        // Session expired — let the app's global handler deal with it
        window.dispatchEvent(new Event('session-expired'));
        return;
      }

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }

      const data = await res.json();
      const reply = data.reply || "Sorry, I couldn't process that request.";

      // Add assistant reply to UI and to conversation history
      setMessages(prev => [
        ...prev,
        { role: 'assistant', text: reply, time: new Date() },
      ]);

      conversationRef.current = [
        ...conversationRef.current,
        { role: 'assistant', content: reply },
      ];
    } catch {
      setMessages(prev => [
        ...prev,
        { role: 'assistant', text: '⚠️ Something went wrong. Please try again.', time: new Date() },
      ]);
    } finally {
      setLoading(false);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [input, loading, user]);

  // ── Keyboard ───────────────────────────────────────────────────────────────
  function handleKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

  // ── Clear chat ─────────────────────────────────────────────────────────────
  function clearChat() {
    initialized.current = false;
    conversationRef.current = [];
    setMessages([]);
    setInput('');
  }

  if (!isAuthenticated || !user) return null;

  const accent = roleColor(user.role);
  const suggestions = getSuggestions(user.role);
  const showSuggestions = messages.length === 1 && !loading;

  return (
    <>
      {/* ── Chat Panel ──────────────────────────────────────────────────── */}
      <div className={`crm-bot-panel ${open ? 'crm-bot-panel--open' : ''}`}>

        {/* Header */}
        <div className="crm-bot-header">
          <div className="crm-bot-header-left">
            <div className="crm-bot-avatar-sm">🤖</div>
            <div>
              <div className="crm-bot-header-title">CRM Assistant</div>
              <div className="crm-bot-header-sub">● Online</div>
            </div>
          </div>
          <div className="crm-bot-header-actions">
            <button className="crm-bot-icon-btn" onClick={clearChat} title="Clear conversation">↺</button>
            <button className="crm-bot-icon-btn" onClick={() => setOpen(false)} title="Close">✕</button>
          </div>
        </div>

        {/* User pill */}
        <div className="crm-bot-user-pill">
          <span className="crm-bot-user-dot" style={{ background: accent }} />
          <span className="crm-bot-user-name">{user.name}</span>
          <span className="crm-bot-user-role" style={{ color: accent }}>{user.role}</span>
        </div>

        {/* Messages */}
        <div className="crm-bot-messages">
          {messages.map((m, i) => (
            <div key={i} className={`crm-bot-msg-row crm-bot-msg-row--${m.role}`}>
              <div className={`crm-bot-bubble crm-bot-bubble--${m.role}`}>
                {renderText(m.text)}
              </div>
              <div className="crm-bot-time">{formatTime(m.time)}</div>
            </div>
          ))}

          {/* Typing dots */}
          {loading && (
            <div className="crm-bot-msg-row crm-bot-msg-row--assistant">
              <div className="crm-bot-bubble crm-bot-bubble--assistant crm-bot-typing">
                <span /><span /><span />
              </div>
            </div>
          )}

          {/* Suggestions */}
          {showSuggestions && (
            <div className="crm-bot-suggestions">
              <div className="crm-bot-suggestions-label">Try asking…</div>
              <div className="crm-bot-suggestions-chips">
                {suggestions.map((s, i) => (
                  <button key={i} className="crm-bot-chip" onClick={() => sendMessage(s)}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div className="crm-bot-input-row">
          <textarea
            ref={inputRef}
            className="crm-bot-input"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask about users, leads, invoices…"
            rows={1}
          />
          <button
            className="crm-bot-send"
            onClick={() => sendMessage()}
            disabled={loading || !input.trim()}
            title="Send (Enter)"
          >
            {loading ? '⏳' : '↑'}
          </button>
        </div>
      </div>

      {/* ── FAB ─────────────────────────────────────────────────────────── */}
      <button
        className={`crm-bot-fab ${open ? 'crm-bot-fab--active' : ''}`}
        onClick={() => setOpen(o => !o)}
        title="CRM Assistant"
        aria-label="Toggle CRM Assistant"
      >
        {open ? '✕' : '🤖'}
      </button>
    </>
  );
}