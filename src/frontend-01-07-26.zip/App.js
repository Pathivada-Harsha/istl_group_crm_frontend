// App.js
import React, { useState, useEffect } from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation
} from 'react-router-dom';

import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import { useAuth } from './hooks/useAuth.js';
import Navbar from './components/Navbar';
import Sidebar from './components/sidebar';
import SessionManager from './components/SessionManager';

// Pages
import Login from './Pages/Login';
import Dashboardtabs from "./Pages/Dashboard.js";
import Leads from "./Pages/Leads-Enquire";
import Proposals from "./Pages/Proposals";
import ProcurementQuatations from "./Pages/Procurement-Quatation-Recieved";
import Invoices from "./Pages/InvoicesReceiptsPage.js";
import TelecallerLeadsPage from "./Pages/Telecallerleadspage.js";
import Customer_dashboard from "./Pages/Sales-Customer";
import Follow_up from "./Pages/Follow-ups";
import Analytics from "./Pages/Analytics";
import Procurement from "./Pages/Procurement-Vendor-Management";
import Documents from "./Pages/Documents";
import Profile from "./Pages/Profile";
import SalesOrder from "./Pages/Sales-Order";
import PurchaseOrders from './Pages/PurchaseOrders';
import BillsRecieved from "./Pages/BillsRecieptsPage.js";
import Reports from "./Pages/ProjectReports.js";
import SolarProfile from "./Pages/Solarproposaleditor";
import Users from "./Pages/UsersPage";
import Addropdownitems from "./Pages/AddNewDropdownItems";
import NewRolePermissions from './Pages/NewRolePermissions';
import Projectdashboard from "./Pages/ProjectDashboard2.js";
import OrderBook from "./Pages/OrderBook.js";
import ProjectCostExpenseManagement from './Pages/ProjectCostExpenseManagement.js';
import NotFound from "./Pages/NotFound";
import TaskManagement from './Pages/TaskManagement.js';
import RoleHierarchyPage from './Pages/RoleHierarchyPage.js';
import './App.css';
import './theme.css';
import { setupFetchInterceptor } from './utils/setupFetchInterceptor';
import ProjectAccessManager from './Pages/ProjectAccessPage.js';
import InventoryManagement from './Pages/InventoryManagement.js';
import { NotificationProvider, NotificationsPage } from './components/Notifications/NotificationModule';
import CRMAssistantBot from './components/CRMAssistantBot';
import TeamLeadPerformance from "./Pages/TeamLeadPerformance.js";

/* ─────────────────────────────────────────────────────────────────────────────
 * useModalScrollLock
 * Watches the DOM with a MutationObserver. Whenever any element with
 * position:fixed covering the full viewport (inset:0) is added or removed,
 * it toggles body.modal-open which applies overflow:hidden via App.css.
 * This prevents the background page from scrolling while ANY modal, drawer,
 * dialog, or overlay is open — across the ENTIRE application in one place.
 * ───────────────────────────────────────────────────────────────────────── */
function isModalOverlay(el) {
  if (!(el instanceof HTMLElement)) return false;
  const s = window.getComputedStyle(el);
  return (
    s.position === 'fixed' &&
    s.top      === '0px'   &&
    s.right    === '0px'   &&
    s.bottom   === '0px'   &&
    s.left     === '0px'
  );
}

function hasOpenModal() {
  const candidates = document.querySelectorAll(
    '[style*="fixed"], [class*="modal"], [class*="overlay"], [class*="backdrop"], [class*="dialog"]'
  );
  for (const el of candidates) {
    if (isModalOverlay(el)) return true;
  }
  return false;
}

function useModalScrollLock() {
  useEffect(() => {
    // Measure scrollbar width once so layout doesn't shift when overflow:hidden
    // removes the scrollbar.
    const sbWidth = window.innerWidth - document.documentElement.clientWidth;
    document.documentElement.style.setProperty('--scrollbar-width', `${sbWidth}px`);

    function syncBodyClass() {
      document.body.classList.toggle('modal-open', hasOpenModal());
    }

    // childList + subtree catches portals rendered anywhere in the tree.
    const observer = new MutationObserver(syncBodyClass);
    observer.observe(document.body, { childList: true, subtree: true });

    syncBodyClass(); // sync once on mount

    return () => {
      observer.disconnect();
      document.body.classList.remove('modal-open');
    };
  }, []);
}

/* ---------------- APP WRAPPER ---------------- */
setupFetchInterceptor();
function AppWrapper() {
  const location = useLocation();

  // Prevent background page scrolling whenever any modal/overlay is open
  useModalScrollLock();

  const hideShell =
    location.pathname === '/login' ||
    location.pathname === '/';

  if (!hideShell) {
    const knownPaths = [
      '/dashboard', '/sales', '/procurement', '/documents',
      '/analytics', '/profile', '/reports', '/solarprofile', '/follow-ups',
      '/users', '/officeuse', '/project-over-view', '/order-book',
      '/project-cost-expense', '/taskmanagement', '/projectaccess', '/inventory-management', '/notifications',
      '/team-performance'
    ];
    const isKnown = knownPaths.some(p => location.pathname.startsWith(p));
    if (!isKnown) return <NotFound />;
  }

  return <AppShell hideShell={hideShell} />;
}

/* ---------------- APP SHELL ---------------- */


function AppShell({ hideShell }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(true);

  const { user } = useAuth();
  const userRole = user?.role || null;

  useEffect(() => {
    const saved = localStorage.getItem("sidebarCollapsed");
    if (saved !== null) setCollapsed(JSON.parse(saved));
  }, []);

  const toggleCollapse = () => {
    setCollapsed(prev => {
      const newVal = !prev;
      localStorage.setItem("sidebarCollapsed", JSON.stringify(newVal));
      return newVal;
    });
  };

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : "sidebar-expanded"}`}>

      {!hideShell && <SessionManager />}

      {!hideShell && <CRMAssistantBot />}
      
      {!hideShell && (
        <Navbar onMenuClick={() => setSidebarOpen(true)} />
      )}

      {!hideShell && (
        <Sidebar
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          collapsed={collapsed}
          onToggleCollapse={toggleCollapse}
        />
      )}

      <main className={`main-content ${hideShell ? "fullpage" : ""}`}>
        <Routes>

          {/* ---------- PUBLIC ---------- */}
          <Route path="/" element={<Login />} />
          <Route path="/login" element={<Login />} />

          {/* ---------- PROTECTED ---------- */}
          <Route path="/dashboard" element={
            <ProtectedRoute><Dashboardtabs /></ProtectedRoute>
          } />

          <Route path="/project-over-view" element={
            <ProtectedRoute><Projectdashboard /></ProtectedRoute>
          } />

          <Route path="/follow-ups" element={
            <ProtectedRoute><Follow_up /></ProtectedRoute>
          } />

          <Route path="/reports" element={
            <ProtectedRoute><Reports /></ProtectedRoute>
          } />

          <Route path="/project-cost-expense" element={
            <ProtectedRoute><ProjectCostExpenseManagement /></ProtectedRoute>
          } />

          <Route path="/inventory-management" element={
            <ProtectedRoute><InventoryManagement /></ProtectedRoute>
          } />

          <Route path="/sales/leads"
            element={
              <ProtectedRoute>
                {userRole === "TELECALLER"
                  ? <TelecallerLeadsPage />
                  : <Leads />}
              </ProtectedRoute>
            }
          />

          <Route path="/sales/clients" element={
            <ProtectedRoute><Customer_dashboard /></ProtectedRoute>
          } />

          <Route path="/order-book" element={
            <ProtectedRoute><OrderBook /></ProtectedRoute>
          } />

          <Route path="/sales/invoices" element={
            <ProtectedRoute><Invoices /></ProtectedRoute>
          } />

          <Route path="/sales/proposals" element={
            <ProtectedRoute><Proposals /></ProtectedRoute>
          } />

          <Route path="/procurement/vendors" element={
            <ProtectedRoute><Procurement /></ProtectedRoute>
          } />

          <Route path="/procurement/quotations" element={
            <ProtectedRoute><ProcurementQuatations /></ProtectedRoute>
          } />

          <Route path="/procurement/purchase-orders" element={
            <ProtectedRoute><PurchaseOrders /></ProtectedRoute>
          } />

          <Route path="/procurement/bills-recieved" element={
            <ProtectedRoute><BillsRecieved /></ProtectedRoute>
          } />

          <Route path="/officeuse/add-group-project" element={
            <ProtectedRoute><Addropdownitems /></ProtectedRoute>
          } />

          <Route path="/officeuse/roles-permissions" element={
            <ProtectedRoute><NewRolePermissions /></ProtectedRoute>
          } />

          {/* ── NEW ──────────────────────────────────────────────────────── */}
          <Route path="/officeuse/role-hierarchy" element={
            <ProtectedRoute><RoleHierarchyPage /></ProtectedRoute>
          } />
          {/* ─────────────────────────────────────────────────────────────── */}

          <Route path="/sales/SalesOrder" element={
            <ProtectedRoute><SalesOrder /></ProtectedRoute>
          } />

          <Route path="/documents" element={
            <ProtectedRoute><Documents /></ProtectedRoute>
          } />

          <Route path="/analytics" element={
            <ProtectedRoute><Analytics /></ProtectedRoute>
          } />
          <Route path="/team-performance" element={
            <ProtectedRoute><TeamLeadPerformance /></ProtectedRoute>
          } />
          <Route path="/profile" element={
            <ProtectedRoute><Profile /></ProtectedRoute>
          } />

          <Route path="/solarprofile" element={
            <ProtectedRoute><SolarProfile /></ProtectedRoute>
          } />

          <Route path="/users" element={
            <ProtectedRoute><Users /></ProtectedRoute>
          } />

          <Route path="/taskmanagement" element={
            <ProtectedRoute><TaskManagement /></ProtectedRoute>
          } />
          <Route path="/officeuse/projectaccess" element={
            <ProtectedRoute><ProjectAccessManager /></ProtectedRoute>
          } />

          <Route path="/notifications" element={
            <ProtectedRoute><NotificationsPage /></ProtectedRoute>
          } />

          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
    </div>
  );
}

/* ---------------- ROOT APP ---------------- */

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <NotificationProvider>
            <AppWrapper />
          </NotificationProvider>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
}