// ─────────────────────────────────────────────────────────────────────────────
//  ItemMakesModal — catalog-level make management for a bom_items_master item.
//  Add / edit / deactivate the makes (variants) available for an item. Which of
//  these a given template line ALLOWS (and the default) is curated separately in
//  the template's BOM tab. Uses the same variant endpoints as that flow.
// ─────────────────────────────────────────────────────────────────────────────
import React, { useState, useEffect, useCallback } from "react";
import { X, Plus, Pencil, Trash2, Check } from "lucide-react";
import api from "../services/leadsapi.js";

const label = (v) => [v?.make, v?.model].filter(Boolean).join(" ").trim() || "(no make)";

const overlay = { position: "fixed", inset: 0, background: "rgba(15,39,72,0.45)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100001 };
const modal = { background: "#fff", borderRadius: 10, padding: 18, width: "min(560px, 94vw)", maxHeight: "90vh", overflow: "auto", boxShadow: "0 12px 40px rgba(0,0,0,0.25)" };
const rowStyle = { display: "flex", alignItems: "center", gap: 8, padding: "6px 0", borderBottom: "1px solid #F1F3F7" };
const iconBtn = { background: "none", border: "none", cursor: "pointer", padding: 2, color: "#6B7280" };

export default function ItemMakesModal({ item, onClose, showError, showSuccess }) {
  const itemId = item?.id;
  const [variants, setVariants] = useState([]);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ id: null, make: "", model: "", description: "" });

  const load = useCallback(async () => {
    if (!itemId) return;
    setLoading(true);
    try {
      const res = await api.get(`/bom-items-master/${itemId}/variants`);
      setVariants(Array.isArray(res?.data) ? res.data : []);
    } catch (e) {
      if (e.message !== "SESSION_EXPIRED") showError?.("Failed to load makes");
    } finally {
      setLoading(false);
    }
  }, [itemId, showError]);

  useEffect(() => { load(); }, [load]);

  const reset = () => setForm({ id: null, make: "", model: "", description: "" });

  const save = async () => {
    if (!form.make.trim() && !form.model.trim()) { showError?.("Enter a make or model"); return; }
    const body = { make: form.make.trim(), model: form.model.trim(), description: form.description.trim() };
    try {
      if (form.id) await api.put(`/bom-item-variants/${form.id}`, body);
      else await api.post(`/bom-items-master/${itemId}/variants`, body);
      reset();
      await load();
      showSuccess?.(form.id ? "Make updated" : "Make added");
    } catch (e) {
      if (e.message !== "SESSION_EXPIRED") showError?.("Failed to save make");
    }
  };

  const edit = (v) => setForm({ id: v.id, make: v.make || "", model: v.model || "", description: v.description || "" });

  const deactivate = async (v) => {
    try {
      await api.delete(`/bom-item-variants/${v.id}`);
      await load();
      showSuccess?.("Make deactivated");
    } catch (e) {
      if (e.message !== "SESSION_EXPIRED") showError?.("Failed to deactivate make");
    }
  };

  if (!item) return null;

  return (
    <div style={overlay} onMouseDown={onClose}>
      <div style={modal} onMouseDown={(e) => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <strong>Makes for “{item.itemName}”</strong>
          <button style={iconBtn} onClick={onClose} title="Close"><X size={16} /></button>
        </div>
        <p style={{ fontSize: 12, color: "#6B7280", margin: "4px 0 10px" }}>
          The makes available for this item. Curate which ones a template line allows (and the default) in the template’s BOM tab.
        </p>

        {loading ? (
          <div style={{ color: "#6B7280" }}>Loading…</div>
        ) : (
          <div style={{ maxHeight: 280, overflowY: "auto" }}>
            {variants.length === 0 && <div style={{ color: "#6B7280" }}>No makes yet. Add one below.</div>}
            {variants.map((v) => {
              const inactive = v.isActive === false;
              return (
                <div key={v.id} style={rowStyle}>
                  <div style={{ flex: 1, opacity: inactive ? 0.5 : 1 }}>
                    <div style={{ fontWeight: 600 }}>{label(v)}{inactive ? " (inactive)" : ""}</div>
                    {v.description && <div style={{ fontSize: 12, color: "#6B7280" }}>{v.description}</div>}
                  </div>
                  <button style={iconBtn} title="Edit" onClick={() => edit(v)}><Pencil size={14} /></button>
                  {!inactive && (
                    <button style={{ ...iconBtn, color: "#DC2626" }} title="Deactivate" onClick={() => deactivate(v)}><Trash2 size={14} /></button>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <div style={{ borderTop: "1px solid #E5E7EB", marginTop: 10, paddingTop: 10 }}>
          <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 6 }}>{form.id ? "Edit make" : "Add a make"}</div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            <input className="bim-inp" style={{ flex: "1 1 100px" }} placeholder="Make / brand"
              value={form.make} onChange={(e) => setForm((f) => ({ ...f, make: e.target.value }))} />
            <input className="bim-inp" style={{ flex: "1 1 90px" }} placeholder="Model"
              value={form.model} onChange={(e) => setForm((f) => ({ ...f, model: e.target.value }))} />
            <input className="bim-inp" style={{ flex: "2 1 160px" }} placeholder="Spec / description"
              value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
            <button className="bim-btn bim-btn-primary" onClick={save}>
              {form.id ? <><Check size={13} /> Update</> : <><Plus size={13} /> Add</>}
            </button>
            {form.id && <button className="bim-btn bim-btn-ghost" onClick={reset}>Cancel</button>}
          </div>
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 14 }}>
          <button className="bim-btn bim-btn-ghost" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}
