// ─────────────────────────────────────────────────────────────────────────────
//  BomItemsMaster — master-data admin for the BOM catalog (bom_items_master).
//
//  Two modes:
//   • Catalog  — the flat item list (search + category), create/edit/deactivate
//                items and manage each item's makes.
//   • Subgroup — pick Group → Subgroup (DB taxonomy) to see the items already
//                used in that subgroup's TEMPLATE BOM (e.g. Rooftop). Each line
//                shows whether it's in the catalog; "Adopt" brings a free-text
//                BOM line into the catalog and links it, so you can then edit its
//                spec + makes instead of re-typing.
// ─────────────────────────────────────────────────────────────────────────────
import React, { useState, useEffect, useCallback } from "react";
import { Plus, Pencil, Trash2, Search, Save, X, Layers, Download } from "lucide-react";
import api from "../services/leadsapi.js";
import filterApi from "../services/filterApi.js";
import useToast from "../hooks/useToast";
import ToastContainer from "../components/Notification_Toast/ToastContainer.js";
import ConfirmationModal from "../components/ConfirmationModal.js";
import useConfirmationModal from "../components/HandleConfirmationModal.js";
import ItemMakesModal from "../components/ItemMakesModal.js";
import "../pages-css/BomItemsMaster.css";

const emptyForm = () => ({
  id: null, category: "", itemName: "", specification: "", description: "",
  defaultUnit: "Nos", defaultTaxPercent: 18, hsnCode: "", isActive: true,
  variantAttributes: [], // [{ key, label, type:"text"|"dropdown"|"number", options:[], unit, required }]
});

// label → stable machine key, e.g. "Max DC Voltage" → "max_dc_voltage"
const slugify = (s) =>
  (s || "").trim().toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");

// The item stores its schema as a JSON string; parse it to the array the builder
// edits. Tolerates an already-parsed array too (some fetch layers auto-parse JSON).
const parseAttrs = (raw) => {
  if (!raw) return [];
  let arr = raw;
  if (typeof raw === "string") {
    try { arr = JSON.parse(raw); } catch { return []; }
  }
  if (!Array.isArray(arr)) return [];
  return arr.map((f) => ({
    key: f.key || "", label: f.label || "", type: f.type || "text",
    optionsText: Array.isArray(f.options) ? f.options.join(", ") : "",
    unit: f.unit || "", required: !!f.required,
    // A field that already has a key (loaded from a saved schema) keeps it frozen,
    // so renaming its label can't orphan variant values keyed by the old key.
    keyLocked: !!(f.key && f.key.trim()),
  }));
};

export default function BomItemsMaster() {
  const { toasts, removeToast, showSuccess, showError } = useToast();
  const { confirmModal, showConfirmation } = useConfirmationModal();

  // Catalog (flat) mode
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  // Taxonomy (subgroup) mode
  const [groups, setGroups] = useState([]);
  const [subGroups, setSubGroups] = useState([]);
  const [group, setGroup] = useState("");
  const [subGroup, setSubGroup] = useState("");
  const [subItems, setSubItems] = useState([]);
  // Slice 3: item category is chosen via Group → Subgroup in the add/edit form.
  const [sgByGroup, setSgByGroup] = useState({}); // groupValue -> [{value,label}]  (subgroups per group)
  const [sgIndex, setSgIndex] = useState({});     // subGroupValue -> groupValue     (reverse lookup for edit)
  const [formGroup, setFormGroup] = useState(""); // selected group in the open modal

  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);
  const [attrErrors, setAttrErrors] = useState({}); // rowIndex -> inline schema-builder error
  const [makesItem, setMakesItem] = useState(null);
  const [adopting, setAdopting] = useState(null); // templateItemId being adopted

  const inSubgroupMode = !!subGroup;

  const loadCatalog = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if (search.trim()) params.search = search.trim();
      if (category) params.category = category;
      const res = await api.get("/bom-items-master/admin", { params });
      setItems(res?.success ? (res.data || []) : []);
    } catch (e) {
      if (e.message !== "SESSION_EXPIRED") showError("Failed to load items");
    } finally { setLoading(false); }
  }, [search, category, showError]);

  const loadSubItems = useCallback(async () => {
    if (!subGroup) return;
    setLoading(true);
    try {
      const res = await api.get("/bom-items-master/by-subgroup", { params: { subGroup } });
      setSubItems(res?.success ? (res.data || []) : []);
    } catch (e) {
      if (e.message !== "SESSION_EXPIRED") showError("Failed to load subgroup BOM items");
    } finally { setLoading(false); }
  }, [subGroup, showError]);

  const reload = useCallback(() => (subGroup ? loadSubItems() : loadCatalog()), [subGroup, loadSubItems, loadCatalog]);

  useEffect(() => { reload(); }, [reload]);

  // Categories (for the catalog filter) + groups (for the taxonomy filter)
  useEffect(() => {
    (async () => {
      try {
        const res = await api.get("/bom-items-master/categories");
        setCategories(res?.success ? (res.data || []) : []);
      } catch { /* non-fatal */ }
      try {
        const g = await filterApi.getAllGroups();
        const groupsArr = Array.isArray(g) ? g : [];
        setGroups(groupsArr);
        // Build the subgroup map/index so the add/edit form can offer Group → Subgroup
        // and pre-select a group when editing an item already categorised by subgroup.
        const entries = await Promise.all(groupsArr.map(async (grp) => {
          try {
            const sg = await filterApi.getSubGroups(grp.value);
            return [grp.value, Array.isArray(sg) ? sg : []];
          } catch { return [grp.value, []]; }
        }));
        const byGroup = {};
        const index = {};
        for (const [gv, sgs] of entries) {
          byGroup[gv] = sgs;
          for (const sg of sgs) index[sg.value] = gv;
        }
        setSgByGroup(byGroup);
        setSgIndex(index);
      } catch { /* non-fatal */ }
    })();
  }, []);

  // Group picker inside the add/edit modal — switching group resets the subgroup (category).
  const onFormGroupChange = (val) => {
    setFormGroup(val);
    setForm((f) => ({ ...f, category: "" }));
  };

  const onGroupChange = async (val) => {
    setGroup(val);
    setSubGroup("");
    setSubGroups([]);
    if (!val) return;
    try {
      const sg = await filterApi.getSubGroups(val);
      setSubGroups(Array.isArray(sg) ? sg : []);
    } catch {
      showError("Failed to load subgroups");
    }
  };

  const openCreate = () => { setFormGroup(""); setAttrErrors({}); setForm(emptyForm()); };
  const openEdit = (it) => {
    const cat = it.category || "";
    setFormGroup(sgIndex[cat] || ""); // pre-select the group if the category is a known subgroup
    setAttrErrors({});
    setForm({
      id: it.id, category: cat, itemName: it.itemName || "",
      specification: it.specification || "", description: it.description || "",
      defaultUnit: it.defaultUnit || "Nos", defaultTaxPercent: it.defaultTaxPercent ?? 18,
      hsnCode: it.hsnCode || "", isActive: it.isActive !== false,
      variantAttributes: parseAttrs(it.variantAttributes),
    });
  };
  const setF = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  // ── Variant-attribute schema builder (Slice 1) ──────────────────────────────
  const addAttr = () => { setAttrErrors({}); setForm((f) => ({
    ...f, variantAttributes: [...f.variantAttributes, { key: "", label: "", type: "text", optionsText: "", unit: "", required: false, keyLocked: false }],
  })); };
  const removeAttr = (i) => { setAttrErrors({}); setForm((f) => ({
    ...f, variantAttributes: f.variantAttributes.filter((_, idx) => idx !== i),
  })); };
  const updateAttr = (i, patch) => { setAttrErrors({}); setForm((f) => ({
    ...f, variantAttributes: f.variantAttributes.map((a, idx) => (idx === i ? { ...a, ...patch } : a)),
  })); };
  // Label drives the key (slug) for new fields; once the key is edited/loaded it's frozen.
  const onAttrLabel = (i, label) => { setAttrErrors({}); setForm((f) => ({
    ...f,
    variantAttributes: f.variantAttributes.map((a, idx) =>
      idx === i ? { ...a, label, key: a.keyLocked ? a.key : slugify(label) } : a),
  })); };
  const onAttrKey = (i, key) => updateAttr(i, { key, keyLocked: true }); // manual edit freezes the key
  const onAttrType = (i, type) => updateAttr(i, { type, optionsText: "", unit: "" });

  const saveForm = async () => {
    if (!form.category.trim()) { showError("Category is required"); return; }
    if (!form.itemName.trim()) { showError("Item name is required"); return; }

    // Validate the variant-attribute schema before saving (server re-checks too).
    // Errors are shown inline under the offending row, not as toasts.
    const attrs = form.variantAttributes || [];
    const optsOf = (a) => (a.optionsText || "").split(",").map((o) => o.trim()).filter(Boolean);
    const keyOf = (a) => slugify(a.key) || slugify(a.label); // editable key, normalized
    const errs = {};
    const seen = new Map();
    attrs.forEach((a, i) => {
      if (!a.label.trim()) { errs[i] = "Label is required."; return; }
      const key = keyOf(a);
      if (!key) { errs[i] = "Key can’t be empty — use letters or digits."; return; }
      if (seen.has(key)) { errs[i] = `Duplicate key “${key}”.`; return; }
      seen.set(key, i);
      if (a.type === "dropdown" && optsOf(a).length === 0) { errs[i] = "Add at least one option."; return; }
    });
    if (Object.keys(errs).length) { setAttrErrors(errs); return; }
    setAttrErrors({});

    setSaving(true);
    // Serialize the schema; send null when empty so legacy items stay schema-less.
    const cleanAttrs = attrs.map((a) => {
      const out = { key: keyOf(a), label: a.label.trim(), type: a.type, required: !!a.required };
      if (a.type === "dropdown") out.options = optsOf(a);
      if (a.type === "number" && a.unit && a.unit.trim()) out.unit = a.unit.trim();
      return out;
    });
    const body = {
      category: form.category.trim(), itemName: form.itemName.trim(),
      specification: form.specification || null, description: form.description || null,
      defaultUnit: form.defaultUnit || null,
      defaultTaxPercent: form.defaultTaxPercent === "" || form.defaultTaxPercent == null ? null : Number(form.defaultTaxPercent),
      hsnCode: form.hsnCode || null, isActive: form.isActive,
      variantAttributes: cleanAttrs.length ? JSON.stringify(cleanAttrs) : null,
    };
    try {
      const res = form.id
        ? await api.put(`/bom-items-master/${form.id}`, body)
        : await api.post(`/bom-items-master`, body);
      if (res?.success) {
        showSuccess(form.id ? "Item updated" : "Item created");
        setForm(null);
        await reload();
      } else {
        showError(res?.message || "Failed to save item");
      }
    } catch (e) {
      if (e.message !== "SESSION_EXPIRED") showError("Failed to save item");
    } finally { setSaving(false); }
  };

  const deactivate = async (it) => {
    const ok = await showConfirmation({
      title: "Deactivate item", type: "alert",
      message: `Deactivate "${it.itemName}"? It stops appearing in pickers but is kept.`,
      confirmText: "Deactivate", cancelText: "Cancel",
    });
    if (!ok) return;
    try {
      const res = await api.delete(`/bom-items-master/${it.id}`);
      if (res?.success) { showSuccess("Item deactivated"); await reload(); }
      else showError(res?.message || "Failed to deactivate");
    } catch (e) {
      if (e.message !== "SESSION_EXPIRED") showError("Failed to deactivate");
    }
  };

  const adopt = async (row) => {
    setAdopting(row.templateItemId);
    try {
      const res = await api.post(`/bom-items-master/adopt`, null, { params: { templateItemId: row.templateItemId } });
      if (res?.success) { showSuccess(`“${row.itemName}” is now in the catalog`); await loadSubItems(); }
      else showError(res?.message || "Failed to adopt item");
    } catch (e) {
      if (e.message !== "SESSION_EXPIRED") showError("Failed to adopt item");
    } finally { setAdopting(null); }
  };

  return (
    <div className="bim-page">
      <ToastContainer toasts={toasts} removeToast={removeToast} />
      <ConfirmationModal {...confirmModal} />

      <div className="bim-head">
        <div className="bim-title">Master Items (BOM catalog)</div>
        <div className="bim-tools">
          <select className="bim-inp" value={group} onChange={(e) => onGroupChange(e.target.value)}>
            <option value="">— Group —</option>
            {groups.map((g) => <option key={g.value} value={g.value}>{g.label || g.value}</option>)}
          </select>
          <select className="bim-inp" value={subGroup} onChange={(e) => setSubGroup(e.target.value)} disabled={!group}>
            <option value="">{group ? "— Subgroup —" : "pick a group"}</option>
            {subGroups.map((sg) => <option key={sg.value} value={sg.value}>{sg.label || sg.value}</option>)}
          </select>

          {!inSubgroupMode && (
            <>
              <div style={{ position: "relative" }}>
                <Search size={14} style={{ position: "absolute", left: 8, top: 8, color: "#9CA3AF" }} />
                <input className="bim-inp" style={{ paddingLeft: 26 }} placeholder="Search name / spec / make"
                  value={search} onChange={(e) => setSearch(e.target.value)} />
              </div>
              <select className="bim-inp" value={category} onChange={(e) => setCategory(e.target.value)}>
                <option value="">All categories</option>
                {categories.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
              <button className="bim-btn bim-btn-primary" onClick={openCreate}><Plus size={14} /> Add item</button>
            </>
          )}
        </div>
      </div>

      {inSubgroupMode && (
        <div className="bim-muted" style={{ marginBottom: 10 }}>
          Items in the <b>{subGroups.find((s) => s.value === subGroup)?.label || subGroup}</b> template BOM.
          “Adopt” brings a line into the catalog so you can edit its spec + makes.
        </div>
      )}

      {loading ? (
        <div className="bim-muted">Loading…</div>
      ) : inSubgroupMode ? (
        /* ── Subgroup BOM view ── */
        <div className="bim-table-wrap">
          <table className="bim-table">
            <thead>
              <tr><th>Scope activity</th><th>Item</th><th>Make</th><th>Specification</th><th>In catalog</th><th /></tr>
            </thead>
            <tbody>
              {subItems.length === 0 && (
                <tr><td colSpan={6} className="bim-muted" style={{ padding: 16 }}>
                  No template BOM for this subgroup yet. Build one in Lead Scope / BOM Templates.
                </td></tr>
              )}
              {subItems.map((r) => (
                <tr key={r.templateItemId}>
                  <td className="bim-muted">{r.scopeActivity || "General"}</td>
                  <td style={{ fontWeight: 600 }}>{r.itemName}</td>
                  <td>{r.make || <span className="bim-muted">—</span>}</td>
                  <td className="bim-muted" style={{ maxWidth: 260, whiteSpace: "pre-wrap" }}>{r.specification || "—"}</td>
                  <td>
                    {r.bomItemId
                      ? <span className="bim-badge bim-badge-on">In catalog</span>
                      : <span className="bim-badge bim-badge-off">Not linked</span>}
                  </td>
                  <td>
                    <div className="bim-actions">
                      {r.bomItemId ? (
                        <>
                          <button className="bim-btn bim-btn-ghost" onClick={() => setMakesItem({ id: r.bomItemId, itemName: r.catalogItem?.itemName || r.itemName })}><Layers size={13} /> Makes</button>
                          {r.catalogItem && (
                            <button className="bim-btn bim-btn-ghost" onClick={() => openEdit(r.catalogItem)}><Pencil size={13} /> Spec</button>
                          )}
                        </>
                      ) : (
                        <button className="bim-btn bim-btn-primary" disabled={adopting === r.templateItemId}
                          onClick={() => adopt(r)}>
                          {adopting === r.templateItemId ? "Adopting…" : <><Download size={13} /> Adopt to catalog</>}
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        /* ── Flat catalog view ── */
        <div className="bim-table-wrap">
          <table className="bim-table">
            <thead>
              <tr>
                <th>Category</th><th>Item name</th><th>Specification</th>
                <th>Unit</th><th>Tax%</th><th>HSN</th><th>Status</th><th />
              </tr>
            </thead>
            <tbody>
              {items.length === 0 && (
                <tr><td colSpan={8} className="bim-muted" style={{ padding: 16 }}>No items. Click “Add item”.</td></tr>
              )}
              {items.map((it) => (
                <tr key={it.id} style={{ opacity: it.isActive === false ? 0.55 : 1 }}>
                  <td>{it.category}</td>
                  <td style={{ fontWeight: 600 }}>{it.itemName}</td>
                  <td className="bim-muted" style={{ maxWidth: 260, whiteSpace: "pre-wrap" }}>{it.specification || "—"}</td>
                  <td>{it.defaultUnit}</td>
                  <td>{it.defaultTaxPercent != null ? `${it.defaultTaxPercent}` : "—"}</td>
                  <td>{it.hsnCode || <span className="bim-muted">—</span>}</td>
                  <td>
                    <span className={`bim-badge ${it.isActive === false ? "bim-badge-off" : "bim-badge-on"}`}>
                      {it.isActive === false ? "Inactive" : "Active"}
                    </span>
                  </td>
                  <td>
                    <div className="bim-actions">
                      <button className="bim-btn bim-btn-ghost" title="Manage makes" onClick={() => setMakesItem(it)}><Layers size={13} /> Makes</button>
                      <button className="bim-btn bim-btn-ghost" title="Edit" onClick={() => openEdit(it)}><Pencil size={13} /></button>
                      {it.isActive !== false && (
                        <button className="bim-btn bim-btn-danger" title="Deactivate" onClick={() => deactivate(it)}><Trash2 size={13} /></button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {form && (
        <div className="bim-overlay" onMouseDown={() => !saving && setForm(null)}>
          <div className="bim-modal" onMouseDown={(e) => e.stopPropagation()}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <strong>{form.id ? "Edit item" : "Add item"}</strong>
              <button className="bim-btn bim-btn-ghost" onClick={() => setForm(null)}><X size={15} /></button>
            </div>

            <div className="bim-field">
              <label>Category — Group → Subgroup *</label>
              <div className="bim-grid2">
                <select className="bim-inp" value={formGroup} onChange={(e) => onFormGroupChange(e.target.value)}>
                  <option value="">— Group —</option>
                  {groups.map((g) => <option key={g.value} value={g.value}>{g.label || g.value}</option>)}
                </select>
                <select className="bim-inp" value={form.category} onChange={(e) => setF("category", e.target.value)} disabled={!formGroup}>
                  <option value="">{formGroup ? "— Subgroup —" : "pick a group"}</option>
                  {(sgByGroup[formGroup] || []).map((sg) => <option key={sg.value} value={sg.value}>{sg.label || sg.value}</option>)}
                </select>
              </div>
              {form.category && !formGroup && (
                <div className="bim-muted" style={{ fontSize: 11, marginTop: 4 }}>
                  Current category: <b>{form.category}</b> — legacy value, kept unless you pick a subgroup above.
                </div>
              )}
            </div>

            <div className="bim-field">
              <label>Item name *</label>
              <input className="bim-inp" value={form.itemName}
                onChange={(e) => setF("itemName", e.target.value)} placeholder="e.g. Solar Module" />
            </div>

            <div className="bim-field">
              <label>Specification</label>
              <textarea className="bim-inp" rows={3} value={form.specification}
                onChange={(e) => setF("specification", e.target.value)} placeholder="Base spec text for this item" />
            </div>
            <div className="bim-field">
              <label>Description</label>
              <textarea className="bim-inp" rows={2} value={form.description}
                onChange={(e) => setF("description", e.target.value)} />
            </div>

            <div className="bim-grid2">
              <div className="bim-field">
                <label>Default unit</label>
                <input className="bim-inp" value={form.defaultUnit} onChange={(e) => setF("defaultUnit", e.target.value)} />
              </div>
              <div className="bim-field">
                <label>Default tax %</label>
                <input className="bim-inp" type="number" min="0" step="any" value={form.defaultTaxPercent}
                  onChange={(e) => setF("defaultTaxPercent", e.target.value)} />
              </div>
              <div className="bim-field">
                <label>HSN code</label>
                <input className="bim-inp" value={form.hsnCode} onChange={(e) => setF("hsnCode", e.target.value)} />
              </div>
            </div>

            {/* ── Variant attributes: the fields each variant of this item will fill ── */}
            <div className="bim-field">
              <label style={{ margin: "0 0 4px" }}>Variant attributes</label>
              <div className="bim-muted" style={{ fontSize: 11, marginBottom: 6 }}>
                Fields each variant (make) of this item fills — e.g. wattage, cell type, face.
              </div>

              {(form.variantAttributes || []).length === 0 ? (
                <div className="bim-muted" style={{ fontSize: 12, padding: "4px 0" }}>
                  No attributes; variants use make/model only.
                </div>
              ) : (
                <div className="bim-attrs">
                  {form.variantAttributes.map((a, i) => (
                    <div className="bim-attr" key={i}>
                      <div className="bim-attr-top">
                        <input className="bim-inp" style={{ flex: "2 1 130px" }} placeholder="Label e.g. Cell Type"
                          value={a.label} onChange={(e) => onAttrLabel(i, e.target.value)} />
                        <input className="bim-inp bim-attr-keyinp" style={{ flex: "1 1 90px" }} placeholder="key"
                          title="Machine key — auto from label, editable"
                          value={a.key} onChange={(e) => onAttrKey(i, e.target.value)} />
                        <select className="bim-inp" value={a.type} onChange={(e) => onAttrType(i, e.target.value)}>
                          <option value="text">Text</option>
                          <option value="dropdown">Dropdown</option>
                          <option value="number">Number</option>
                        </select>
                        <label className="bim-attr-req" title="A variant must fill this field">
                          <input type="checkbox" checked={a.required}
                            onChange={(e) => updateAttr(i, { required: e.target.checked })} /> Req
                        </label>
                        <button type="button" className="bim-attr-x" title="Remove field"
                          onClick={() => removeAttr(i)}>×</button>
                      </div>
                      {a.type === "dropdown" && (
                        <input className="bim-inp" style={{ width: "100%", marginTop: 6 }} value={a.optionsText}
                          placeholder="Options, comma-separated e.g. Monofacial, Bifacial"
                          onChange={(e) => updateAttr(i, { optionsText: e.target.value })} />
                      )}
                      {a.type === "number" && (
                        <input className="bim-inp" style={{ width: 140, marginTop: 6 }} value={a.unit}
                          placeholder="Unit e.g. Wp, kW" onChange={(e) => updateAttr(i, { unit: e.target.value })} />
                      )}
                      {attrErrors[i] && <div className="bim-attr-err">{attrErrors[i]}</div>}
                    </div>
                  ))}
                </div>
              )}

              <button type="button" className="bim-btn bim-btn-ghost" style={{ marginTop: 8 }} onClick={addAttr}>
                <Plus size={13} /> Add field
              </button>
            </div>

            {form.id && (
              <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13 }}>
                <input type="checkbox" checked={form.isActive} onChange={(e) => setF("isActive", e.target.checked)} /> Active
              </label>
            )}

            <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 14 }}>
              <button className="bim-btn bim-btn-ghost" onClick={() => setForm(null)}>Cancel</button>
              <button className="bim-btn bim-btn-primary" onClick={saveForm} disabled={saving}>
                <Save size={14} /> {saving ? "Saving…" : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}

      {makesItem && (
        <ItemMakesModal item={makesItem} onClose={() => { setMakesItem(null); if (subGroup) loadSubItems(); }}
          showError={showError} showSuccess={showSuccess} />
      )}
    </div>
  );
}
