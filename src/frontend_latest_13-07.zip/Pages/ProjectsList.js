// src/Pages/ProjectsList.js
//
// Projects module — LIST page (route: /projects).
// Structural sibling of Pages/OrderBook.js but project-centric: 4 summary
// stat cards, an apply-on-change AND filter bar (search → Group → Sub-Group →
// Status → Clear), a table/grid view toggle persisted to localStorage, and
// client-side pagination. Row/card click opens /projects/:projectUniqueId.
//
// Data: GET /projects?search=&groupId=&subGroupName=&status=  (JSON ARRAY).
// The Group dropdown value is a group NAME (filterApi.getAllGroups() returns
// { value: groupName, label }); per spec it is passed as the `groupId` param.

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import filterApi from '../services/filterApi.js';
import projectsApi from '../services/projectsApi.js';
import FilterSelect from '../components/Dropdowns/FilterSelect.js';
import { useAuth } from '../hooks/useAuth.js';
import useToast from '../hooks/useToast';
import ToastContainer from '../components/Notification_Toast/ToastContainer.js';
import CrmPreloader from '../components/preLoader.js';
import '../pages-css/OrderBook.css';
import '../pages-css/Projects.css';

// Status colour map — copied from Pages/ProjectDashboard.js getStatusColor.
const getStatusColor = (s) => ({
  NOT_STARTED: '#64748b', PLANNING: '#f59e0b', IN_PROGRESS: '#3b82f6',
  COMPLETED: '#22c55e', ON_HOLD: '#8b5cf6', CANCELLED: '#ef4444',
}[s] || '#94a3b8');

const STATUS_OPTIONS = [
  { value: 'NOT_STARTED', label: 'Not Started' },
  { value: 'PLANNING',    label: 'Planning' },
  { value: 'IN_PROGRESS', label: 'In Progress' },
  { value: 'COMPLETED',   label: 'Completed' },
  { value: 'ON_HOLD',     label: 'On Hold' },
  { value: 'CANCELLED',   label: 'Cancelled' },
];

const statusLabel = (s) =>
  STATUS_OPTIONS.find(o => o.value === s)?.label || (s ? String(s).replace(/_/g, ' ') : '-');

// Progress-fill colour by status: green COMPLETED, amber ON_HOLD, else accent blue.
const progressColor = (s) => (s === 'COMPLETED' ? '#22c55e' : s === 'ON_HOLD' ? '#f59e0b' : '#3b82f6');

// Group pill flavour from the group name (EPC blue / IoT green / CBG amber).
const groupPillClass = (groupName) => {
  const g = String(groupName || '').toUpperCase();
  if (g.includes('EPC')) return 'pl-group-pill pl-group-pill--epc';
  if (g.includes('IOT')) return 'pl-group-pill pl-group-pill--iot';
  if (g.includes('CBG')) return 'pl-group-pill pl-group-pill--cbg';
  return 'pl-group-pill';
};

const fmtMoney = (n) => {
  const v = Number(n || 0);
  return '₹' + v.toLocaleString('en-IN', { maximumFractionDigits: 0 });
};
const fmtDate = (d) => {
  if (!d) return '—';
  const dt = new Date(d);
  if (isNaN(dt)) return '—';
  return `${String(dt.getDate()).padStart(2, '0')}-${String(dt.getMonth() + 1).padStart(2, '0')}-${dt.getFullYear()}`;
};

const ROWS_PER_PAGE = 10;

function ProjectsList() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toasts, removeToast, showError } = useToast();

  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(false);

  // Filters (apply-on-change)
  const [search, setSearch] = useState('');
  const [groupName, setGroupName] = useState('');       // dropdown value == group NAME
  const [subGroupName, setSubGroupName] = useState('');
  const [status, setStatus] = useState('');

  const [groupOptions, setGroupOptions] = useState([]);
  const [subGroupOptions, setSubGroupOptions] = useState([]);
  const [subGroupsLoading, setSubGroupsLoading] = useState(false);

  const [viewMode, setViewMode] = useState(() => localStorage.getItem('projects_view_mode') || 'table');
  const [currentPage, setCurrentPage] = useState(1);

  const setView = (mode) => { setViewMode(mode); localStorage.setItem('projects_view_mode', mode); };

  // ── Load group options once ────────────────────────────────────────────────
  useEffect(() => {
    (async () => {
      try { setGroupOptions(await filterApi.getAllGroups()); }
      catch { setGroupOptions([]); }
    })();
  }, []);

  // ── Cascade: when Group changes, (re)load sub-groups; clear resets + disables ─
  useEffect(() => {
    if (!groupName) { setSubGroupOptions([]); return; }
    let cancelled = false;
    setSubGroupsLoading(true);
    (async () => {
      try {
        const subs = await filterApi.getSubGroups(groupName);
        if (!cancelled) setSubGroupOptions(Array.isArray(subs) ? subs : []);
      } catch {
        if (!cancelled) setSubGroupOptions([]);
      } finally {
        if (!cancelled) setSubGroupsLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [groupName]);

  const onGroupChange = (v) => {
    setGroupName(v);
    setSubGroupName('');   // reset sub-group whenever the group changes/clears
  };

  // ── Fetch projects whenever filters change (debounced on search) ────────────
  const fetchProjects = useCallback(async () => {
    setLoading(true);
    try {
      const data = await projectsApi.listProjects({
        search: search.trim() || undefined,
        groupId: groupName || undefined,       // dropdown value is a group name; spec param is groupId
        subGroupName: subGroupName || undefined,
        status: status || undefined,
      });
      setProjects(Array.isArray(data) ? data : (data?.data || []));
      setCurrentPage(1);
    } catch (err) {
      showError(err.message || 'Failed to load projects');
      setProjects([]);
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, groupName, subGroupName, status, user?.id]);

  useEffect(() => {
    const t = setTimeout(fetchProjects, search ? 400 : 0);
    return () => clearTimeout(t);
  }, [fetchProjects, search]);

  const clearFilters = () => {
    setSearch(''); setGroupName(''); setSubGroupName(''); setStatus('');
  };
  const hasFilters = search || groupName || subGroupName || status;

  // ── Summary stats (from the fetched list) ───────────────────────────────────
  const stats = useMemo(() => {
    const total = projects.length;
    const inProgress = projects.filter(p => p.status === 'IN_PROGRESS').length;
    const completed = projects.filter(p => p.status === 'COMPLETED').length;
    const totalBudget = projects.reduce((s, p) => s + Number(p.budget || 0), 0);
    return { total, inProgress, completed, totalBudget };
  }, [projects]);

  // ── Pagination (client-side slice) ──────────────────────────────────────────
  const totalPages = Math.max(1, Math.ceil(projects.length / ROWS_PER_PAGE));
  const pageItems = useMemo(
    () => projects.slice((currentPage - 1) * ROWS_PER_PAGE, currentPage * ROWS_PER_PAGE),
    [projects, currentPage]
  );

  const openProject = (p) => navigate(`/projects/${encodeURIComponent(p.projectUniqueId)}`);

  return (
    <div className="orderbook-page">
      <ToastContainer toasts={toasts} removeToast={removeToast} />

      {/* Header */}
      <div className="orderbook-header">
        <h1>Projects</h1>
      </div>

      {/* Summary stat cards */}
      <div className="pl-stats">
        <div className="pl-stat-card">
          <span className="pl-stat-label">Total Projects</span>
          <span className="pl-stat-value">{stats.total}</span>
          <span className="pl-stat-accent" style={{ background: '#3b82f6' }} />
        </div>
        <div className="pl-stat-card">
          <span className="pl-stat-label">In Progress</span>
          <span className="pl-stat-value">{stats.inProgress}</span>
          <span className="pl-stat-accent" style={{ background: getStatusColor('IN_PROGRESS') }} />
        </div>
        <div className="pl-stat-card">
          <span className="pl-stat-label">Completed</span>
          <span className="pl-stat-value">{stats.completed}</span>
          <span className="pl-stat-accent" style={{ background: getStatusColor('COMPLETED') }} />
        </div>
        <div className="pl-stat-card">
          <span className="pl-stat-label">Total Budget</span>
          <span className="pl-stat-value">{fmtMoney(stats.totalBudget)}</span>
          <span className="pl-stat-accent" style={{ background: '#8b5cf6' }} />
        </div>
      </div>

      {/* Filter bar */}
      <div className="pl-filterbar">
        <input
          className="pl-search"
          type="text"
          placeholder="Search project or customer…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <div className="pl-filter-cell">
          <FilterSelect
            value={groupName}
            options={groupOptions}
            placeholder="All Groups"
            onChange={onGroupChange}
          />
        </div>
        <div className="pl-filter-cell">
          <FilterSelect
            value={subGroupName}
            options={subGroupOptions}
            placeholder={!groupName ? 'Select Group First' : subGroupsLoading ? 'Loading…' : 'All Sub-Groups'}
            disabled={!groupName || subGroupsLoading}
            onChange={setSubGroupName}
          />
        </div>
        <div className="pl-filter-cell">
          <FilterSelect
            value={status}
            options={STATUS_OPTIONS}
            placeholder="All Statuses"
            onChange={setStatus}
          />
        </div>
        {hasFilters && (
          <button className="pl-clear-btn" onClick={clearFilters}>Clear Filters</button>
        )}

        {/* View toggle */}
        <div className="pl-view-toggle">
          <button
            className={`pl-view-btn${viewMode === 'table' ? ' active' : ''}`}
            onClick={() => setView('table')}
            title="Table view"
            aria-label="Table view"
          >▤</button>
          <button
            className={`pl-view-btn${viewMode === 'grid' ? ' active' : ''}`}
            onClick={() => setView('grid')}
            title="Grid view"
            aria-label="Grid view"
          >⊞</button>
        </div>
      </div>

      {/* Body */}
      {loading ? (
        <CrmPreloader />
      ) : projects.length === 0 ? (
        <div className="pl-empty">No projects found{hasFilters ? ' for the selected filters.' : '.'}</div>
      ) : (
        <>
          {viewMode === 'table'
            ? <ProjectsTable rows={pageItems} onOpen={openProject} />
            : <ProjectsGrid rows={pageItems} onOpen={openProject} />}

          {/* Pagination */}
          <div className="pl-pagination">
            <span className="pl-page-info">
              Showing {(currentPage - 1) * ROWS_PER_PAGE + 1}–{Math.min(currentPage * ROWS_PER_PAGE, projects.length)} of {projects.length}
            </span>
            <div className="pl-page-btns">
              <button className="pl-page-btn" disabled={currentPage === 1} onClick={() => setCurrentPage(p => Math.max(1, p - 1))}>‹</button>
              {Array.from({ length: totalPages }, (_, i) => i + 1)
                .filter(p => Math.abs(p - currentPage) <= 2 || p === 1 || p === totalPages)
                .map((p, idx, arr) => (
                  <React.Fragment key={p}>
                    {idx > 0 && p - arr[idx - 1] > 1 && <span className="pl-page-info">…</span>}
                    <button
                      className={`pl-page-btn${p === currentPage ? ' active' : ''}`}
                      onClick={() => setCurrentPage(p)}
                    >{p}</button>
                  </React.Fragment>
                ))}
              <button className="pl-page-btn" disabled={currentPage === totalPages} onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}>›</button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
//  TABLE VIEW
// ─────────────────────────────────────────────────────────────────────────────
const ProjectsTable = ({ rows, onOpen }) => (
  <div className="pl-table-wrap">
    <table className="pl-table">
      <thead>
        <tr>
          <th>Project ID</th>
          <th>Project Name</th>
          <th>Group</th>
          <th>Status</th>
          <th>Budget</th>
          <th>Progress</th>
          <th>Timeline</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((p) => {
          const pct = Math.min(100, Math.max(0, Number(p.progressPercentage || 0)));
          return (
            <tr key={p.projectUniqueId} onClick={() => onOpen(p)}>
              <td>
                <div className="pl-id-main">{p.projectUniqueId}</div>
                <div className="pl-muted-sm">{p.customerName || '—'}</div>
              </td>
              <td>{p.projectName || '—'}</td>
              <td><span className={groupPillClass(p.groupName)}>{p.groupName || '—'}</span></td>
              <td>
                <span
                  className="pl-status-badge"
                  style={{ background: getStatusColor(p.status) + '22', color: getStatusColor(p.status) }}
                >
                  {statusLabel(p.status)}
                </span>
              </td>
              <td>{fmtMoney(p.budget)}</td>
              <td>
                <div className="pl-progress-wrap">
                  <div className="pl-progress">
                    <div className="pl-progress-fill" style={{ width: `${pct}%`, background: progressColor(p.status) }} />
                  </div>
                  <span className="pl-progress-pct">{pct}%</span>
                </div>
              </td>
              <td className="pl-muted-sm">{fmtDate(p.startDate)} → {fmtDate(p.endDate)}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
  </div>
);

// ─────────────────────────────────────────────────────────────────────────────
//  GRID VIEW
// ─────────────────────────────────────────────────────────────────────────────
const ProjectsGrid = ({ rows, onOpen }) => (
  <div className="pl-grid">
    {rows.map((p) => {
      const pct = Math.min(100, Math.max(0, Number(p.progressPercentage || 0)));
      return (
        <div key={p.projectUniqueId} className="pl-card" onClick={() => onOpen(p)}>
          <div className="pl-card-head">
            <span className={groupPillClass(p.groupName)}>{p.groupName || '—'}</span>
            <span
              className="pl-status-badge"
              style={{ background: getStatusColor(p.status) + '22', color: getStatusColor(p.status) }}
            >
              {statusLabel(p.status)}
            </span>
          </div>

          <div>
            <div className="pl-card-name">{p.projectName || '—'}</div>
            <div className="pl-card-customer">{p.customerName || '—'}</div>
          </div>

          <div className="pl-card-divider" />

          <div className="pl-card-row">
            <label>Budget</label>
            <span className="pl-card-value">{fmtMoney(p.budget)}</span>
          </div>

          <div className="pl-progress-wrap">
            <div className="pl-progress">
              <div className="pl-progress-fill" style={{ width: `${pct}%`, background: progressColor(p.status) }} />
            </div>
            <span className="pl-progress-pct">{pct}%</span>
          </div>

          <div className="pl-card-foot">
            <span className="pl-muted-sm">{fmtDate(p.startDate)} → {fmtDate(p.endDate)}</span>
            <span className="pl-card-id">{p.projectUniqueId}</span>
          </div>
        </div>
      );
    })}
  </div>
);

export default ProjectsList;
