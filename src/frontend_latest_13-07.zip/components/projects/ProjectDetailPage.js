// src/components/Projects/ProjectDetailPage.js
//
// Projects module — DETAIL page (route: /projects/:projectUniqueId).
// Ports the OrderBookDetailPage structure (header card + persisted obd-tab bar)
// but project-centric and fully EDITABLE. The three execution tabs reuse the
// ported tab components (Scope/SOW, Financials, Progress & Timeline), which hit
// the /projects/{id}/... endpoints that MIRROR the Order Book detail endpoints.
//
// The ported tab components expect an `orderBook` prop; we hand them a
// project-shaped shim ({ id: projectUniqueId, subGroupName, orderTitle, ... }).

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth.js';
import useToast from '../../hooks/useToast';
import ToastContainer from '../Notification_Toast/ToastContainer.js';
import CrmPreloader from '../preLoader.js';
import projectsApi from '../../services/projectsApi.js';
import { TechnicalTab, CommercialTab, BomTab, ProgressTab } from './orderBookTabsPorted.js';
import '../../pages-css/OrderBookDetail.css';
import '../../pages-css/Projects.css';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

const getStatusColor = (s) => ({
  NOT_STARTED: '#64748b', PLANNING: '#f59e0b', IN_PROGRESS: '#3b82f6',
  COMPLETED: '#22c55e', ON_HOLD: '#8b5cf6', CANCELLED: '#ef4444',
}[s] || '#94a3b8');
const statusLabel = (s) => (s ? String(s).replace(/_/g, ' ') : '—');
const progressColor = (s) => (s === 'COMPLETED' ? '#22c55e' : s === 'ON_HOLD' ? '#f59e0b' : '#3b82f6');
const groupPillClass = (g) => {
  const G = String(g || '').toUpperCase();
  if (G.includes('EPC')) return 'pl-group-pill pl-group-pill--epc';
  if (G.includes('IOT')) return 'pl-group-pill pl-group-pill--iot';
  if (G.includes('CBG')) return 'pl-group-pill pl-group-pill--cbg';
  return 'pl-group-pill';
};
const fmtMoney = (n) => '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 });
const fmtDate = (d) => {
  if (!d) return '—';
  const dt = new Date(d);
  if (isNaN(dt)) return '—';
  return `${String(dt.getDate()).padStart(2, '0')}-${String(dt.getMonth() + 1).padStart(2, '0')}-${dt.getFullYear()}`;
};

const TABS = [
  { k: 'scope',      l: 'Scope / SOW' },
  { k: 'financials', l: 'Financials' },
  { k: 'progress',   l: 'Progress & Timeline' },
];

const ProjectDetailPage = () => {
  const { projectUniqueId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toasts, removeToast, showSuccess, showError } = useToast();

  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('scope');
  const [linkedOrderBookId, setLinkedOrderBookId] = useState(null);

  const authHeaders = useMemo(
    () => ({ 'User-Id': String(user?.id || ''), 'User-Role': String(user?.role || '') }),
    [user]
  );

  // ── Header fetch ────────────────────────────────────────────────────────────
  const loadProject = useCallback(async () => {
    setLoading(true);
    try {
      const data = await projectsApi.getProject(projectUniqueId);
      // Endpoint may return the entity directly or wrapped in { data }.
      setProject(data?.data ? data.data : data);
    } catch (err) {
      showError(err.message || 'Failed to load project');
      setProject(null);
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectUniqueId]);

  useEffect(() => { loadProject(); }, [loadProject]);
  useEffect(() => { setActiveTab('scope'); }, [projectUniqueId]);

  // ── Resolve the linked order book (for the "View Order Book →" link) ─────────
  // The Order Book list rows carry `projectId`; find the one matching this
  // project and deep-link to /order-book?view=<id> (OrderBook.js opens detail
  // via ?view=). Degrades silently — the link only renders when one is found.
  useEffect(() => {
    if (!projectUniqueId || !user?.id) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/order-book/getAll?page=0&size=1000`, {
          credentials: 'include', headers: authHeaders,
        });
        if (!res.ok) return;
        const data = await res.json();
        const list = data?.data || [];
        const match = list.find(o => String(o.projectId) === String(projectUniqueId));
        if (!cancelled && match) setLinkedOrderBookId(match.id);
      } catch { /* non-fatal: link just won't render */ }
    })();
    return () => { cancelled = true; };
  }, [projectUniqueId, user?.id, authHeaders]);

  // ── Project-shaped shim for the ported tab components ───────────────────────
  const obShim = useMemo(() => {
    if (!project) return null;
    return {
      ...project,
      id: project.projectUniqueId || projectUniqueId,
      orderTitle: project.projectName,
      subGroupName: project.subGroupName,
    };
  }, [project, projectUniqueId]);

  if (loading) return <div className="obd-page"><CrmPreloader /></div>;

  if (!project) {
    return (
      <div className="obd-page">
        <ToastContainer toasts={toasts} removeToast={removeToast} />
        <button
          onClick={() => navigate('/projects')}
          style={{ background: 'none', border: 'none', color: '#3b82f6', fontWeight: 600, cursor: 'pointer', padding: '8px 0', display: 'inline-flex', alignItems: 'center', gap: 6 }}
        >
          <ArrowLeft size={16} /> Back to Projects
        </button>
        <div className="pl-empty">Project not found.</div>
      </div>
    );
  }

  const pct = Math.min(100, Math.max(0, Number(project.progressPercentage || 0)));

  return (
    <div className="obd-page">
      <ToastContainer toasts={toasts} removeToast={removeToast} />

      {/* Back button — plain text, no border */}
      <button
        onClick={() => navigate('/projects')}
        style={{ background: 'none', border: 'none', color: '#3b82f6', fontWeight: 600, cursor: 'pointer', padding: '8px 0', display: 'inline-flex', alignItems: 'center', gap: 6, marginBottom: 4 }}
      >
        <ArrowLeft size={16} /> Back to Projects
      </button>

      {/* Header card */}
      <div className="obd-header-card">
        <div className="obd-header-main">
          <h1 className="obd-title">{project.projectName || project.projectUniqueId}</h1>
          <div className="obd-subline" style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            <span
              className="pl-status-badge"
              style={{ background: getStatusColor(project.status) + '22', color: getStatusColor(project.status) }}
            >
              {statusLabel(project.status)}
            </span>
            {project.groupName && <span className={groupPillClass(project.groupName)}>{project.groupName}</span>}
            {project.customerName && <span className="obd-chip">{project.customerName}</span>}
          </div>
        </div>

        {/* "View Order Book →" — subtle secondary link, top-right */}
        {linkedOrderBookId && (
          <button
            className="pd-secondary-link"
            onClick={() => navigate(`/order-book?view=${linkedOrderBookId}`)}
          >
            View Order Book →
          </button>
        )}

        {/* Metric strip */}
        <div className="pd-metric-strip" style={{ flexBasis: '100%' }}>
          <div className="pd-metric"><label>Project ID</label><span>{project.projectUniqueId}</span></div>
          <div className="pd-metric"><label>Budget</label><span>{fmtMoney(project.budget)}</span></div>
          <div className="pd-metric"><label>Timeline</label><span>{fmtDate(project.startDate)} → {fmtDate(project.endDate)}</span></div>
          <div className="pd-metric pd-metric--progress">
            <label>Progress</label>
            <div className="pl-progress-wrap">
              <div className="pl-progress">
                <div className="pl-progress-fill" style={{ width: `${pct}%`, background: progressColor(project.status) }} />
              </div>
              <span className="pl-progress-pct">{pct}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tab bar */}
      <div className="obd-tabbar">
        {TABS.map(t => (
          <button
            key={t.k}
            className={`obd-tab${activeTab === t.k ? ' active' : ''}`}
            onClick={() => setActiveTab(t.k)}
          >{t.l}</button>
        ))}
      </div>

      <div className="obd-tab-body">
        {activeTab === 'scope'      && <ProjectScopeTab      orderBook={obShim} authHeaders={authHeaders} showSuccess={showSuccess} showError={showError} />}
        {activeTab === 'financials' && <ProjectFinancialsTab orderBook={obShim} authHeaders={authHeaders} showSuccess={showSuccess} showError={showError} />}
        {activeTab === 'progress'   && <ProjectProgressTab   orderBook={obShim} authHeaders={authHeaders} showError={showError} />}
      </div>
    </div>
  );
};

// ── Distinct project-named wrappers around the ported editable tabs ──────────
const ProjectScopeTab = (props) => <TechnicalTab {...props} />;

const ProjectFinancialsTab = (props) => (
  <>
    <CommercialTab {...props} />
    <div style={{ height: 18 }} />
    <BomTab {...props} />
  </>
);

const ProjectProgressTab = (props) => <ProgressTab {...props} />;

export default ProjectDetailPage;
