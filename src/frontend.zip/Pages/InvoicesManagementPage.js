// Old Invoices page
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Eye, Edit2, Trash2, DollarSign, Download, Send, ChevronUp, ChevronDown, Columns, GripVertical, Check } from 'lucide-react';
import '../pages-css/Invoices.css';
import GroupProjectFilter from "./../components/Dropdowns/GroupProjectFilter.js";
import useGroupProjectFilters from "./../components/Dropdowns/useGroupProjectFilters.js";
import { useAuth } from "../hooks/useAuth.js";
import ConfirmationModal from '../components/ConfirmationModal';
import useToast from '../hooks/useToast';
import ToastContainer from './../components/Notification_Toast/ToastContainer.js';
import CrmPreloader from "../components/preLoader.js";
import filterApi from '../services/filterApi';
import UnitTypeDropdown from './../components/Dropdowns/Unittypedropdown.js';
import { normalizeUnit } from './../components/Dropdowns/unitUtils';
import { FaIndianRupeeSign } from "react-icons/fa6";

const API_BASE_URL = process.env.REACT_APP_API_URL;

const InvoicesManagementPage = () => {
  const [invoices, setInvoices] = useState([]);
  const { groupName, subGroupName, projectId, updateFilters } = useGroupProjectFilters();
  const { user, pagePermissions, isAccountsExecutive } = useAuth();
  const invoicesPerms = pagePermissions?.INVOICES || [];
  const canCreate = invoicesPerms.includes('CREATE') || isAccountsExecutive;
  const canEdit   = invoicesPerms.includes('EDIT')   || isAccountsExecutive;
  const canDelete = invoicesPerms.includes('DELETE') && !isAccountsExecutive;
  const { toasts, removeToast, showSuccess, showError } = useToast();
  const [confirmModal, setConfirmModal] = useState({ show: false, title: '', message: '', type: 'error', onConfirm: null });
  const [loading, setLoading] = useState(false);
  const [paymentHistory, setPaymentHistory] = useState([]);
  const [filters, setFilters] = useState({
    search: '',
    status: 'all',
    paymentStatus: 'all'
  });

  // Pagination
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [totalElements, setTotalElements] = useState(0);
  const [pageSize, setPageSize] = useState(10);

  // Column sorting
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });

  // Column visibility & order
  const INVOICE_COLUMNS = [
    { key: 'customerId',    label: 'Customer Name' },
    { key: 'totalAmount',   label: 'Total Amount' },
    { key: 'paidAmount',    label: 'Paid Amount' },
    { key: 'balanceAmount', label: 'Balance' },
    { key: 'status',        label: 'Status' },
    { key: 'invoiceDate',   label: 'Invoice Date' },
    { key: 'dueDate',       label: 'Due Date' },
  ];
  const [columnOrder, setColumnOrder] = useState(INVOICE_COLUMNS.map(c => c.key));
  const [visibleColumns, setVisibleColumns] = useState(INVOICE_COLUMNS.map(c => c.key));
  const [showColumnsPanel, setShowColumnsPanel] = useState(false);
  const columnsPanelRef = useRef(null);
  const dragColRef = useRef(null);
  const dragOverColRef = useRef(null);

  // Modal states
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [stats, setStats] = useState(null);

  // Dropdown states
  const [modalGroups, setModalGroups] = useState([]);
  const [modalSubGroups, setModalSubGroups] = useState([]);
  const [modalProjects, setModalProjects] = useState([]);
  const [modalGroupName, setModalGroupName] = useState('');
  const [modalSubGroupName, setModalSubGroupName] = useState('');
  const [modalProjectId, setModalProjectId] = useState('');
  const [modalDropdownLoading, setModalDropdownLoading] = useState({
    groups: false,
    subGroups: false,
    projects: false
  });
  const [orderBooks, setOrderBooks] = useState([]);
  const [selectedOrderBookId, setSelectedOrderBookId] = useState('');
  const [orderBookItems, setOrderBookItems] = useState([]);
  const [filteredItems, setFilteredItems] = useState({});
  const [showDropdown, setShowDropdown] = useState({});
  const [loadingOrderBookItems, setLoadingOrderBookItems] = useState(false);
  
  // Customer data
  const [customerData, setCustomerData] = useState(null);

  // Form states
  const [formData, setFormData] = useState({
    customerId: null,
    projectId: '',
    groupId: '',
    subGroupId: '',
    invoiceDate: new Date().toISOString().split('T')[0],
    dueDate: '',
    items: [{ description: '', quantity: '', unitPrice: '', taxPercent: '', unitType: '' }],
    status: 'DRAFT'
  });

  const fetchOrderBookItemsForCustomer = async (customerId) => {
    if (!customerId) {
      setOrderBookItems([]);
      return;
    }

    try {
      const response = await fetch(`${API_BASE_URL}/invoices/order-book-items-by-customer/${customerId}`, {
        credentials: "include",
        headers: getAuthHeaders()
      });

      if (!response.ok) throw new Error('Failed to fetch order book items');

      const data = await response.json();
      setOrderBookItems(data.data || []);
      console.log('Loaded order book items:', data);

    } catch (error) {
      console.error('Failed to fetch order book items:', error);
      setOrderBookItems([]);
    }
  };

  // Step 1: Fetch all order books for this project and populate the dropdown
  const fetchProjectOrderBookItems = async (pId, gName, sgName) => {
    if (!pId) { setOrderBooks([]); setOrderBookItems([]); setSelectedOrderBookId(''); return; }
    setLoadingOrderBookItems(true);
    try {
      // Send groupName + subGroupName + projectId so it works whether or not
      // the backend supports the projectId param (old or new backend).
      // Client-side filter by projectId guarantees correctness either way.
      const group = encodeURIComponent(gName || modalGroupName || '');
      const subGroup = encodeURIComponent(sgName || modalSubGroupName || '');
      const obRes = await fetch(
        `${API_BASE_URL}/order-book/getAll?page=0&size=200&groupName=${group}&subGroupName=${subGroup}&projectId=${encodeURIComponent(pId)}`,
        { credentials: 'include', headers: getAuthHeaders() }
      );
      if (!obRes.ok) throw new Error();
      const obData = await obRes.json();
      // Filter client-side by projectId to handle old backend that ignores the param
      const all = (obData.data || obData.content || []).filter(ob => ob.projectId === pId);
      setOrderBooks(all);
      setSelectedOrderBookId('');
      setOrderBookItems([]);
      // If exactly one order book, auto-select and load items
      if (all.length === 1) {
        setSelectedOrderBookId(String(all[0].id));
        await fetchOrderBookItemsById(all[0].id);
      }
    } catch { setOrderBooks([]); setOrderBookItems([]); }
    finally { setLoadingOrderBookItems(false); }
  };

  // Step 2: Fetch items for a specific order book (called when user selects from dropdown)
  const fetchOrderBookItemsById = async (orderBookId) => {
    if (!orderBookId) { setOrderBookItems([]); return; }
    setLoadingOrderBookItems(true);
    try {
      const itemsRes = await fetch(
        `${API_BASE_URL}/order-book/${orderBookId}/items-with-tracking`,
        { credentials: 'include', headers: getAuthHeaders() }
      );
      if (!itemsRes.ok) throw new Error();
      const itemsData = await itemsRes.json();
      setOrderBookItems(itemsData.success ? (itemsData.data || []) : (Array.isArray(itemsData) ? itemsData : []));
    } catch { setOrderBookItems([]); }
    finally { setLoadingOrderBookItems(false); }
  };

  // Handle order book selection from dropdown
  const handleOrderBookSelect = async (e) => {
    const obId = e.target.value;
    setSelectedOrderBookId(obId);
    setOrderBookItems([]);
    if (obId) await fetchOrderBookItemsById(obId);
  };

  const handleLoadOrderBookItems = () => {
    if (orderBookItems.length === 0) { showError('No order book items available'); return; }
    const loaded = orderBookItems.map(item => {
      const totalQty = parseFloat(item.quantity) || 0;
      const allocatedQty = parseFloat(item.invoicedQty) || 0;  // qty already invoiced
      const remainingQty = Math.max(0, totalQty - allocatedQty);
      return {
        description: item.itemName || '',
        quantity: remainingQty,
        unitPrice: parseFloat(item.unitPrice) || 0,
        taxPercent: parseFloat(item.taxPercent) || 18,
        unitType: normalizeUnit(item.unit),
        orderBookItemId: item.id,
        maxQty: remainingQty,
        totalQty,
        allocatedQty
      };
    }).filter(it => it.maxQty > 0);
    if (loaded.length === 0) { showError('All order book items are fully invoiced already'); return; }
    setFormData(prev => ({ ...prev, items: loaded }));
    showSuccess(`Loaded ${loaded.length} item${loaded.length !== 1 ? 's' : ''} from order book`);
  };

  // Update payment form data
  const [paymentData, setPaymentData] = useState({
    amount: 0,
    method: 'Bank Transfer',
    transactionReference: '',
    notes: ''
  });

  const selectOrderBookItem = (index, item) => {
    const newItems = [...formData.items];
    newItems[index] = {
      ...newItems[index],
      description: item.itemName,
      quantity: item.quantity || 1,
      unitPrice: item.unitPrice || 0,
      taxPercent: item.taxPercent || 18,
      unitType: normalizeUnit(item.unit),
      orderBookItemId: item.id
    };

    setFormData({ ...formData, items: newItems });
    setShowDropdown(prev => ({ ...prev, [index]: false }));
    setFilteredItems(prev => ({ ...prev, [index]: [] }));
  };

  // Fetch invoices on mount and filter change
  useEffect(() => {
    fetchInvoices();
  }, [groupName, subGroupName, projectId, currentPage, pageSize, filters.status, filters.search]);

  // Fetch stats when filters change
  useEffect(() => {
    fetchStats();
  }, [groupName, subGroupName, projectId]);

  const handleDownloadPdf = async (invoice) => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/invoices/${invoice.id}/download-pdf`, {
        credentials: "include",
        headers: getAuthHeaders()
      });

      if (!response.ok) throw new Error('Failed to download PDF');

      const contentDisposition = response.headers.get('Content-Disposition');
      let filename = `Invoice-${invoice.invoiceNo}.pdf`;
      if (contentDisposition) {
        const matches = /filename="([^"]+)"/.exec(contentDisposition);
        if (matches && matches[1]) filename = matches[1];
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      showSuccess('Invoice PDF downloaded successfully!');

    } catch (error) {
      console.error('Failed to download PDF:', error);
      showError('Failed to download PDF');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Get auth headers
   */
  const getAuthHeaders = () => ({
    'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
    'X-User-Id': user?.id || localStorage.getItem('userId'),
    'X-User-Role': user?.role || localStorage.getItem('userRole'),
    'User-Id': user?.id || localStorage.getItem('userId'),
    'User-Role': user?.role || localStorage.getItem('userRole')
  });

  /**
   * Fetch invoices from backend
   */
  const fetchInvoices = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: currentPage,
        size: pageSize,
        sortBy: 'invoiceDate',
        sortDirection: 'DESC'
      });

      if (groupName) params.append('groupId', groupName);
      if (subGroupName) params.append('subGroupId', subGroupName);
      if (projectId) params.append('projectId', projectId);
      if (filters.status !== 'all') params.append('status', filters.status);
      if (filters.search) params.append('searchTerm', filters.search);

      const response = await fetch(`${API_BASE_URL}/invoices?${params}`, {
        credentials: "include",
        headers: getAuthHeaders()
      });

      if (!response.ok) throw new Error('Failed to fetch invoices');

      const data = await response.json();
      
      setInvoices(data.invoices || []);
      setTotalPages(data.totalPages || 0);
      setTotalElements(data.totalElements || 0);

    } catch (error) {
      console.error('Failed to fetch invoices:', error);
      showError('Failed to load invoices');
      setInvoices([]);
    } finally {
      setLoading(false);
    }
  };

  // Click outside handler to close dropdown
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest('.Invoices-page-form-group')) {
        setShowDropdown({});
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  /**
   * Fetch statistics with filters
   */
const fetchStats = async () => {
  try {
    const params = new URLSearchParams();

    // Scope filters
    if (groupName) params.append("groupId", groupName);
    if (subGroupName) params.append("subGroupId", subGroupName);
    if (projectId) params.append("projectId", projectId);

    // Only apply createdBy filter for non-admin users.
    // Admins should see company-wide KPI numbers, not just their own invoices.
    const isAdmin = user?.role === "ADMIN" || user?.role === "SUPERADMIN";
    if (user?.id && !isAdmin) params.append("createdBy", user.id);

    const response = await fetch(
      `${API_BASE_URL}/invoices/summary?${params.toString()}`,
      {
        method: "GET",
        credentials: "include",
        headers: getAuthHeaders(),
      }
    );

    if (response.ok) {
      const data = await response.json();
      setStats(data);
    } else {
      console.error("Failed to fetch stats");
      setStats({
        totalCount: 0,
        paidCount: 0,
        pendingCount: 0,
        totalAmount: 0,
      });
    }
  } catch (error) {
    console.error("Failed to fetch stats:", error);
    setStats({
      totalCount: 0,
      paidCount: 0,
      pendingCount: 0,
      totalAmount: 0,
    });
  }
};


  /**
   * Fetch modal groups — uses direct fetch with session credentials
   * (filterApi uses localStorage Bearer token which is empty in session-based auth)
   */
  const fetchModalGroups = async () => {
    setModalDropdownLoading(prev => ({ ...prev, groups: true }));
    try {
      const response = await fetch(`${API_BASE_URL}/filters/groups`, {
        credentials: 'include',
        headers: getAuthHeaders()
      });
      if (!response.ok) throw new Error('Failed to fetch groups');
      const groups = await response.json();
      setModalGroups(Array.isArray(groups) ? groups : []);
    } catch (error) {
      console.error('Failed to fetch groups:', error);
      setModalGroups([]);
    } finally {
      setModalDropdownLoading(prev => ({ ...prev, groups: false }));
    }
  };

  /**
   * Fetch modal subgroups — uses direct fetch with session credentials
   */
  const fetchModalSubGroups = async (groupName) => {
    if (!groupName) {
      setModalSubGroups([]);
      return;
    }
    setModalDropdownLoading(prev => ({ ...prev, subGroups: true }));
    try {
      const response = await fetch(
        `${API_BASE_URL}/filters/subgroups?groupName=${encodeURIComponent(groupName)}`,
        { credentials: 'include', headers: getAuthHeaders() }
      );
      if (!response.ok) throw new Error('Failed to fetch subgroups');
      const subGroups = await response.json();
      setModalSubGroups(Array.isArray(subGroups) ? subGroups : []);
    } catch (error) {
      console.error('Failed to fetch subgroups:', error);
      setModalSubGroups([]);
    } finally {
      setModalDropdownLoading(prev => ({ ...prev, subGroups: false }));
    }
  };

  /**
   * Fetch modal projects
   */
  const fetchModalProjects = async (groupName, subGroupName) => {
    if (!groupName || !subGroupName) {
      setModalProjects([]);
      return;
    }

    setModalDropdownLoading(prev => ({ ...prev, projects: true }));
    try {
      const projects = await filterApi.getProjects(groupName, subGroupName);
      setModalProjects(projects || []);
    } catch (error) {
      console.error('Failed to fetch projects:', error);
      showError('Failed to load projects');
      setModalProjects([]);
    } finally {
      setModalDropdownLoading(prev => ({ ...prev, projects: false }));
    }
  };

  /**
   * Fetch customer by project ID
   */
  const fetchCustomerByProject = async (projectId) => {
    if (!projectId) {
      setCustomerData(null);
      setOrderBookItems([]); setOrderBooks([]); setSelectedOrderBookId('');
      return;
    }

    try {
      const response = await fetch(`${API_BASE_URL}/invoices/customer-by-project/${projectId}`, {
        credentials: "include",
        headers: getAuthHeaders()
      });

      if (response.ok) {
        const data = await response.json();
        setCustomerData(data);
        setFormData(prev => ({ ...prev, customerId: data.customerId }));
        // Order book items are fetched by project scope via fetchProjectOrderBookItems — not by customer
      } else {
        setCustomerData(null);
        setOrderBookItems([]); setOrderBooks([]); setSelectedOrderBookId('');
        showError('Customer not found for this project');
      }
    } catch (error) {
      console.error('Failed to fetch customer:', error);
      setCustomerData(null);
      setOrderBookItems([]); setOrderBooks([]); setSelectedOrderBookId('');
    }
  };

  const handleDescriptionChange = (index, value) => {
    updateItem(index, 'description', value);

    if (!value || value.length < 2) {
      setFilteredItems(prev => ({ ...prev, [index]: [] }));
      setShowDropdown(prev => ({ ...prev, [index]: false }));
      return;
    }

    const searchLower = value.toLowerCase();
    const filtered = orderBookItems.filter(item =>
      item.itemName?.toLowerCase().includes(searchLower) ||
      item.specification?.toLowerCase().includes(searchLower)
    ).slice(0, 10);

    setFilteredItems(prev => ({ ...prev, [index]: filtered }));
    setShowDropdown(prev => ({ ...prev, [index]: filtered.length > 0 }));
  };

  /**
   * Handle modal group change
   */
  const handleModalGroupChange = (e) => {
    const newGroupName = e.target.value;
    setModalGroupName(newGroupName);
    setModalSubGroupName('');
    setModalProjectId('');
    setModalSubGroups([]);
    setModalProjects([]);
    setCustomerData(null);

    setOrderBookItems([]); setOrderBooks([]); setSelectedOrderBookId('');
    setFormData({ ...formData, groupId: newGroupName, subGroupId: '', projectId: '', customerId: null, items: [{ description: '', quantity: '', unitPrice: '', taxPercent: '', unitType: '' }] });
    if (newGroupName) { fetchModalSubGroups(newGroupName); }
  };

  /**
   * Handle modal subgroup change
   */
  const handleModalSubGroupChange = (e) => {
    const newSubGroupName = e.target.value;
    setModalSubGroupName(newSubGroupName);
    setModalProjectId('');
    setModalProjects([]);
    setCustomerData(null);

    setOrderBookItems([]); setOrderBooks([]); setSelectedOrderBookId('');
    setFormData({ ...formData, subGroupId: newSubGroupName, projectId: '', customerId: null, items: [{ description: '', quantity: '', unitPrice: '', taxPercent: '', unitType: '' }] });
    if (modalGroupName && newSubGroupName) { fetchModalProjects(modalGroupName, newSubGroupName); }
  };

  /**
   * Handle modal project change
   */
  const handleModalProjectChange = (e) => {
    const newProjectId = e.target.value;
    setModalProjectId(newProjectId);
    setOrderBookItems([]); setOrderBooks([]); setSelectedOrderBookId('');
    setFormData({ ...formData, projectId: newProjectId, items: [{ description: '', quantity: '', unitPrice: '', taxPercent: '', unitType: '' }] });
    if (newProjectId) {
      fetchCustomerByProject(newProjectId);
      // Pass group/subgroup explicitly to avoid stale closure issues
      fetchProjectOrderBookItems(newProjectId, modalGroupName, modalSubGroupName);
    }
  };

  /**
   * View invoice
   */
  const handleViewInvoice = async (invoice) => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/invoices/${invoice.id}`, {
        credentials: "include",
        headers: getAuthHeaders()
      });

      if (!response.ok) throw new Error('Failed to fetch invoice details');

      const data = await response.json();
      setSelectedInvoice(data);

      const historyResponse = await fetch(`${API_BASE_URL}/invoices/${invoice.id}/payment-history`, {
        credentials: "include",
        headers: getAuthHeaders()
      });

      if (historyResponse.ok) {
        const historyData = await historyResponse.json();
        setPaymentHistory(historyData);
      }

      setShowInvoiceModal(true);
    } catch (error) {
      console.error('Failed to fetch invoice details:', error);
      showError('Failed to load invoice details');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Create new invoice
   */
  const handleCreateNew = () => {
    setFormData({
      customerId: null,
      projectId: '',
      groupId: '',
      subGroupId: '',
      invoiceDate: new Date().toISOString().split('T')[0],
      dueDate: '',
      items: [{ description: '', quantity: '', unitPrice: '', taxPercent: '', unitType: '' }],
      status: 'DRAFT'
    });
    setCustomerData(null);
    setModalGroupName(''); setModalSubGroupName(''); setModalProjectId('');
    setOrderBookItems([]); setOrderBooks([]); setSelectedOrderBookId('');
    setEditMode(false);

    fetchModalGroups();
    setShowCreateModal(true);
  };

  /**
   * Edit invoice
   */
  const handleEditInvoice = async (invoice) => {
    setFormData({
      customerId: invoice.customerId,
      projectId: invoice.projectId,
      groupId: invoice.groupId,
      subGroupId: invoice.subGroupId,
      invoiceDate: invoice.invoiceDate.split('T')[0],
      dueDate: invoice.dueDate ? invoice.dueDate.split('T')[0] : '',
      items: invoice.items || [{ description: '', quantity: '', unitPrice: '', taxPercent: '', unitType: '' }],
      status: invoice.status
    });
    setSelectedInvoice(invoice);
    setEditMode(true);

    // Await groups BEFORE opening the modal so the select is never empty
    await fetchModalGroups();

    // Set the selected group after groups are confirmed loaded
    if (invoice.groupId) {
      setModalGroupName(invoice.groupId);
      // Also pre-load subgroups for the saved group
      await fetchModalSubGroups(invoice.groupId);
      if (invoice.subGroupId) {
        setModalSubGroupName(invoice.subGroupId);
      }
    }

    setShowCreateModal(true);
  };

  /**
   * Add item
   */
  const addItem = () => {
    setFormData({
      ...formData,
      items: [...formData.items, { description: '', quantity: '', unitPrice: '', taxPercent: '', unitType: '' }]
    });
  };

  /**
   * Update item
   */
  const updateItem = (index, field, value) => {
    const newItems = [...formData.items];
    newItems[index][field] = value;
    setFormData({ ...formData, items: newItems });
  };

  /**
   * Remove item
   */
  const removeItem = (index) => {
    if (formData.items.length > 1) {
      const newItems = formData.items.filter((_, i) => i !== index);
      setFormData({ ...formData, items: newItems });
    }
  };

  /**
   * Calculate invoice totals
   */
  const calculateInvoice = () => {
    let subtotal = 0;
    let taxTotal = 0;

    formData.items.forEach(item => {
      const lineTotal = item.quantity * item.unitPrice;
      const lineTax = (lineTotal * item.taxPercent) / 100;
      subtotal += lineTotal;
      taxTotal += lineTax;
    });

    return {
      subtotal,
      taxTotal,
      grandTotal: subtotal + taxTotal
    };
  };

  /**
   * Save invoice
   */
  const handleSaveInvoice = async (status) => {
    if (!formData.customerId) {
      showError('Please select a project to auto-fill customer details');
      return;
    }

    if (formData.items.length === 0 || !formData.items[0].description) {
      showError('Please add at least one item');
      return;
    }

    setLoading(true);
    try {
      const invoiceData = {
        ...formData,
        status: status,
        items: formData.items.map(item => ({
          description: item.description,
          quantity: parseFloat(item.quantity),
          unitPrice: parseFloat(item.unitPrice),
          taxPercent: parseFloat(item.taxPercent),
          unitType: item.unitType,
          orderBookItemId: item.orderBookItemId || null
        }))
      };

      const url = editMode
        ? `${API_BASE_URL}/invoices/${selectedInvoice.id}`
        : `${API_BASE_URL}/invoices`;

      const response = await fetch(url, {
        credentials: "include",
        method: editMode ? 'PUT' : 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify(invoiceData)
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to save invoice');
      }

      showSuccess(`Invoice ${editMode ? 'updated' : 'created'} successfully!`);
      setShowCreateModal(false);
      fetchInvoices();
      fetchStats();

    } catch (error) {
      console.error('Failed to save invoice:', error);
      showError(error.message || 'Failed to save invoice');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Record payment
   */
  const handleRecordPayment = (invoice) => {
    setSelectedInvoice(invoice);
    setPaymentData({
      amount: parseFloat(invoice.balanceAmount || invoice.totalAmount),
      method: 'Bank Transfer',
      notes: ''
    });
    setShowPaymentModal(true);
  };

  /**
   * Save payment
   */
  const handleSavePayment = async () => {
    if (paymentData.amount <= 0) {
      showError('Payment amount must be greater than zero');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/invoices/${selectedInvoice.id}/payment`, {
        credentials: "include",
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({ amount: paymentData.amount })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to record payment');
      }

      showSuccess('Payment recorded successfully!');
      setShowPaymentModal(false);
      fetchInvoices();
      fetchStats();

    } catch (error) {
      console.error('Failed to record payment:', error);
      showError(error.message || 'Failed to record payment');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Delete invoice
   */
  const handleDeleteInvoice = (id) => {
    if (!canDelete) { showError('No permission to delete invoices'); return; }
    setConfirmModal({
      show: true, title: 'Delete Invoice',
      message: 'Are you sure you want to delete this invoice? This action cannot be undone.',
      type: 'error',
      onConfirm: () => performDeleteInvoice(id)
    });
  };
  const performDeleteInvoice = async (id) => {
    setConfirmModal({ show: false });

    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/invoices/${id}`, {
        credentials: "include",
        method: 'DELETE',
        headers: getAuthHeaders()
      });

      if (!response.ok) throw new Error('Failed to delete invoice');

      showSuccess('Invoice deleted successfully!');
      fetchInvoices();
      fetchStats();

    } catch (error) {
      console.error('Failed to delete invoice:', error);
      showError('Failed to delete invoice');
    } finally {
      setLoading(false);
    }
  };

  // Helper functions
  const formatCurrency = (amount) => {
    if (!amount && amount !== 0) return '₹0.00';
    const num = typeof amount === 'number' ? amount : parseFloat(amount) || 0;
    return `₹${num.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-IN', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  const getStatusClass = (status) => {
    const statusMap = {
      'DRAFT': 'Invoices-page-status-draft',
      'SENT': 'Invoices-page-status-sent',
      'PAID': 'Invoices-page-status-paid',
      'PARTIALLY_PAID': 'Invoices-page-payment-partial',
      'CANCELLED': 'Invoices-page-status-cancelled'
    };
    return statusMap[status] || '';
  };

  const getStatusDisplayName = (status) => {
    const statusMap = {
      'DRAFT': 'Draft',
      'SENT': 'Sent',
      'PAID': 'Paid',
      'PARTIALLY_PAID': 'Partially Paid',
      'CANCELLED': 'Cancelled'
    };
    return statusMap[status] || status;
  };

  // Close columns panel when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (columnsPanelRef.current && !columnsPanelRef.current.contains(e.target)) {
        setShowColumnsPanel(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Sorting
  const handleSort = (key) => {
    setSortConfig(prev =>
      prev.key === key
        ? { key, direction: prev.direction === 'asc' ? 'desc' : 'asc' }
        : { key, direction: 'asc' }
    );
  };

  const getSortedInvoices = () => {
    if (!sortConfig.key) return invoices;
    return [...invoices].sort((a, b) => {
      let aVal = a[sortConfig.key] ?? '';
      let bVal = b[sortConfig.key] ?? '';
      if (typeof aVal === 'string') aVal = aVal.toLowerCase();
      if (typeof bVal === 'string') bVal = bVal.toLowerCase();
      if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });
  };

  const SortIcon = ({ colKey }) => {
    if (sortConfig.key !== colKey) return <ChevronUp size={13} style={{ opacity: 0.3, marginLeft: 3 }} />;
    return sortConfig.direction === 'asc'
      ? <ChevronUp size={13} style={{ marginLeft: 3, color: '#6366f1' }} />
      : <ChevronDown size={13} style={{ marginLeft: 3, color: '#6366f1' }} />;
  };

  // Drag-and-drop column reorder
  const handleColDragStart = (key) => { dragColRef.current = key; };
  const handleColDragOver = (e, key) => { e.preventDefault(); dragOverColRef.current = key; };
  const handleColDrop = () => {
    const from = dragColRef.current;
    const to   = dragOverColRef.current;
    if (!from || !to || from === to) return;
    setColumnOrder(prev => {
      const arr = [...prev];
      const fi = arr.indexOf(from);
      const ti = arr.indexOf(to);
      arr.splice(fi, 1);
      arr.splice(ti, 0, from);
      return arr;
    });
    dragColRef.current = null;
    dragOverColRef.current = null;
  };

  // Toggle column visibility
  const toggleColumn = (key) => {
    setVisibleColumns(prev =>
      prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]
    );
  };

  // Ordered, visible columns
  const orderedVisibleCols = columnOrder.filter(k => visibleColumns.includes(k));
  const colMeta = Object.fromEntries(INVOICE_COLUMNS.map(c => [c.key, c]));

  return (
    <div className="Invoices-page-container">
      {loading && <CrmPreloader text="Loading..." />}
      <ToastContainer toasts={toasts} removeToast={removeToast} />
      <ConfirmationModal
        show={confirmModal.show}
        title={confirmModal.title}
        message={confirmModal.message}
        type={confirmModal.type}
        onConfirm={confirmModal.onConfirm}
        onCancel={() => setConfirmModal({ show: false })}
      />

      {/* Breadcrumb */}
      <div className="Invoices-page-breadcrumb">
        <span>Pages</span>
        <span className="Invoices-page-separator">{'>'}</span>
        <span className="Invoices-page-current">Invoices</span>
      </div>

      <div className="page-header-with-filter">
        <h1 className="Invoices-page-title">Invoices ({totalElements})</h1>
        <GroupProjectFilter
          groupValue={groupName}
          subGroupValue={subGroupName}
          projectValue={projectId}
          onChange={updateFilters}
        />
      </div>

      {/* Action Bar */}
      <div className="Invoices-page-action-bar">
        <div className="Invoices-page-search-filters">
          <input
            type="text"
            className="Invoices-page-search"
            placeholder="Search invoices by ID..."
            value={filters.search}
            onChange={(e) => {
              setFilters({ ...filters, search: e.target.value });
              setCurrentPage(0);
            }}
          />

          <select
            className="Invoices-page-filter"
            value={filters.status}
            onChange={(e) => {
              setFilters({ ...filters, status: e.target.value });
              setCurrentPage(0);
            }}
          >
            <option value="all">All Status</option>
            <option value="DRAFT">Draft</option>
            <option value="SENT">Sent</option>
            <option value="PAID">Paid</option>
            <option value="PARTIALLY_PAID">Partially Paid</option>
            <option value="CANCELLED">Cancelled</option>
          </select>
        </div>

        <div className="Invoices-page-actions">
          <div className="col-toggle-wrapper" ref={columnsPanelRef} style={{ position: 'relative', display: 'inline-block' }}>
            <button
              className="Invoices-page-btn-columns"
              onClick={() => setShowColumnsPanel(p => !p)}
              title="Toggle Columns"
              style={{
                display: 'inline-flex', alignItems: 'center', gap: '6px',
                padding: '8px 14px', border: '1px solid #e2e8f0', borderRadius: '8px',
                background: '#fff', cursor: 'pointer', fontSize: '14px', color: '#374151',
                fontWeight: 500
              }}
            >
              <Columns size={16} />
              Columns
            </button>
            {showColumnsPanel && (
              <div style={{
                position: 'absolute', top: 'calc(100% + 6px)', right: 0, zIndex: 999,
                background: '#fff', border: '1px solid #e2e8f0', borderRadius: '10px',
                boxShadow: '0 8px 24px rgba(0,0,0,0.12)', padding: '10px 0', minWidth: '200px'
              }}>
                <div style={{ padding: '6px 14px 10px', fontSize: '12px', fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.05em', borderBottom: '1px solid #f1f5f9' }}>
                  Show / Hide Columns
                </div>
                {INVOICE_COLUMNS.map(col => (
                  <div
                    key={col.key}
                    onClick={() => toggleColumn(col.key)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: '10px',
                      padding: '8px 14px', cursor: 'pointer', fontSize: '14px', color: '#374151',
                      transition: 'background 0.15s'
                    }}
                    onMouseEnter={e => e.currentTarget.style.background = '#f8fafc'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                  >
                    <div style={{
                      width: 17, height: 17, borderRadius: 4, border: '1.5px solid',
                      borderColor: visibleColumns.includes(col.key) ? '#6366f1' : '#d1d5db',
                      background: visibleColumns.includes(col.key) ? '#6366f1' : '#fff',
                      display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0
                    }}>
                      {visibleColumns.includes(col.key) && <Check size={11} color="#fff" strokeWidth={3} />}
                    </div>
                    {col.label}
                  </div>
                ))}
              </div>
            )}
          </div>
          <button className={`Invoices-page-btn-primary${!canCreate ? ' action-btn-disabled' : ''}`} onClick={() => canCreate && handleCreateNew()} disabled={!canCreate} title={!canCreate ? "No create permission" : "Create New Invoice"}>
            + Create New Invoice
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="Invoices-page-stats">
          <div className="Invoices-page-stat-card">
            <div className="Invoices-page-stat-label">TOTAL INVOICES</div>
            <div className="Invoices-page-stat-value">{stats.totalCount || 0}</div>
          </div>
          <div className="Invoices-page-stat-card">
            <div className="Invoices-page-stat-label">PAID</div>
            <div className="Invoices-page-stat-value Invoices-page-stat-success">
              {stats.paidCount || 0}
            </div>
          </div>
          <div className="Invoices-page-stat-card">
            <div className="Invoices-page-stat-label">PENDING</div>
            <div className="Invoices-page-stat-value Invoices-page-stat-warning">
              {stats.pendingCount || 0}
            </div>
          </div>
          <div className="Invoices-page-stat-card">
            <div className="Invoices-page-stat-label">TOTAL AMOUNT</div>
            <div className="Invoices-page-stat-value">
              {formatCurrency(stats.totalAmount)}
            </div>
          </div>
        </div>
      )}

      {/* Invoices Table */}
      <div className="Invoices-page-table-container">
        <table className="Invoices-page-table">
          <thead>
            <tr>
              {orderedVisibleCols.map(key => (
                <th
                  key={key}
                  draggable
                  onDragStart={() => handleColDragStart(key)}
                  onDragOver={(e) => handleColDragOver(e, key)}
                  onDrop={handleColDrop}
                  onClick={() => handleSort(key)}
                  style={{ cursor: 'pointer', userSelect: 'none', whiteSpace: 'nowrap' }}
                >
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                    <GripVertical size={13} style={{ opacity: 0.35, cursor: 'grab', flexShrink: 0 }} />
                    {colMeta[key].label}
                    <SortIcon colKey={key} />
                  </span>
                </th>
              ))}
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {invoices.length === 0 ? (
              <tr>
                <td colSpan={orderedVisibleCols.length + 1} className="empty-state">
                  No invoices found
                </td>
              </tr>
            ) : (
              getSortedInvoices().map((invoice) => (
                <tr key={invoice.id}>
                  {orderedVisibleCols.map(key => {
                    if (key === 'customerId')    return <td key={key}>{invoice.customerCompanyName || invoice.customerName || `#${invoice.customerId}`}</td>;
                    if (key === 'totalAmount')   return <td key={key} className="Invoices-page-total">{formatCurrency(invoice.totalAmount)}</td>;
                    if (key === 'paidAmount')    return <td key={key}>{formatCurrency(invoice.paidAmount)}</td>;
                    if (key === 'balanceAmount') return <td key={key} className="Invoices-page-total">{formatCurrency(invoice.balanceAmount)}</td>;
                    if (key === 'status')        return (
                      <td key={key}>
                        <span className={`Invoices-page-badge ${getStatusClass(invoice.status)}`}>
                          {getStatusDisplayName(invoice.status)}
                        </span>
                      </td>
                    );
                    if (key === 'invoiceDate')   return <td key={key}>{formatDate(invoice.invoiceDate)}</td>;
                    if (key === 'dueDate')       return <td key={key}>{formatDate(invoice.dueDate)}</td>;
                    return <td key={key}>—</td>;
                  })}
                  <td>
                    <div className="Invoices-page-action-buttons">
                      <button
                        className="Invoices-page-action-btn Invoices-page-btn-view"
                        onClick={() => handleViewInvoice(invoice)}
                        title="View"
                      >
                        <Eye size={16} />
                      </button>
                      <button
                        className={`Invoices-page-action-btn Invoices-page-btn-edit${!canEdit ? ' action-btn-disabled' : ''}`}
                        onClick={() => canEdit && handleEditInvoice(invoice)}
                        title={canEdit ? "Edit" : "No edit permission"}
                        disabled={!canEdit}
                      >
                        <Edit2 size={16} />
                      </button>
                      <button
                        className="Invoices-page-action-btn Invoices-page-btn-download"
                        onClick={() => handleDownloadPdf(invoice)}
                        title="Download PDF"
                      >
                        <Download size={16} />
                      </button>
                      <button
                        className={`Invoices-page-action-btn Invoices-page-btn-payment${!canEdit ? ' action-btn-disabled' : ''}`}
                        onClick={() => canEdit && handleRecordPayment(invoice)}
                        title={canEdit ? "Record Payment" : "No permission"}
                        disabled={!canEdit}
                      >
                        <FaIndianRupeeSign size={16} />
                      </button>
                      {canDelete && (
                      <button
                        className="Invoices-page-action-btn Invoices-page-btn-delete"
                        onClick={() => handleDeleteInvoice(invoice.id)}
                        title="Delete"
                      >
                        <Trash2 size={16} />
                      </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>

        {/* Pagination */}
        <div className="Invoices-page-pagination">
          <div className="Invoices-page-pagination-info">
            Showing {currentPage * pageSize + 1} to {Math.min((currentPage + 1) * pageSize, totalElements)} of {totalElements} invoices
          </div>

          <div className="Invoices-page-pagination-controls-wrapper">
            <div className="Invoices-page-pagination-size">
              <label>Rows per page:</label>
              <select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setCurrentPage(0);
                }}
                className="Invoices-page-pagination-size-select"
              >
                <option value="5">5</option>
                <option value="10">10</option>
                <option value="25">25</option>
                <option value="50">50</option>
                <option value="100">100</option>
              </select>
            </div>

            <div className="Invoices-page-pagination-controls">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 0))}
                disabled={currentPage === 0}
                className="Invoices-page-pagination-btn"
              >
                Previous
              </button>
              <span className="Invoices-page-pagination-current">
                Page {currentPage + 1} of {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages - 1))}
                disabled={currentPage >= totalPages - 1}
                className="Invoices-page-pagination-btn"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* View Invoice Modal */}
      {showInvoiceModal && selectedInvoice && (
        <div className="Invoices-page-modal-overlay">
          <div className="Invoices-page-modal Invoices-page-modal-large" onClick={e => e.stopPropagation()}>
            <div className="Invoices-page-modal-header">
              <h2>Invoice Details - {selectedInvoice.invoiceNo}</h2>
              <button className="Invoices-page-modal-close" onClick={() => setShowInvoiceModal(false)}>×</button>
            </div>

            <div className="Invoices-page-modal-body">
              <div className="Invoices-page-invoice-view">
                <div className="Invoices-page-invoice-meta">
                  <div className="Invoices-page-invoice-meta-item">
                    <strong>Invoice Date:</strong> {formatDate(selectedInvoice.invoiceDate)}
                  </div>
                  <div className="Invoices-page-invoice-meta-item">
                    <strong>Due Date:</strong> {formatDate(selectedInvoice.dueDate)}
                  </div>
                  <div className="Invoices-page-invoice-meta-item">
                    <strong>Status:</strong>
                    <span className={`Invoices-page-badge ${getStatusClass(selectedInvoice.status)}`}>
                      {getStatusDisplayName(selectedInvoice.status)}
                    </span>
                  </div>
                </div>

                <div className="Invoices-page-invoice-section">
                  <h3>Invoice Items</h3>
                  <table className="Invoices-page-invoice-items-table">
                    <thead>
                      <tr>
                        <th>Description</th>
                        <th>Unit Type</th>
                        <th>Qty</th>
                        <th>Unit Price</th>
                        <th>Tax %</th>
                        <th>Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedInvoice.items && selectedInvoice.items.map((item, index) => {
                        const lineTotal = item.quantity * item.unitPrice;
                        const lineTax = (lineTotal * item.taxPercent) / 100;
                        return (
                          <tr key={index}>
                            <td>{item.description}</td>
                            <td>{item.unitType}</td>
                            <td>{item.quantity}</td>
                            <td>{formatCurrency(item.unitPrice)}</td>
                            <td>{item.taxPercent}%</td>
                            <td>{formatCurrency(lineTotal + lineTax)}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {paymentHistory && paymentHistory.length > 0 && (
                  <div className="Invoices-page-invoice-section">
                    <h3>Payment History</h3>
                    <table className="Invoices-page-invoice-items-table">
                      <thead>
                        <tr>
                          <th>Date</th>
                          <th>Amount</th>
                          <th>Method</th>
                          <th>Reference</th>
                          <th>Notes</th>
                        </tr>
                      </thead>
                      <tbody>
                        {paymentHistory.map((payment, index) => (
                          <tr key={index}>
                            <td>{formatDate(payment.paymentDate)}</td>
                            <td className="Invoices-page-text-success">{formatCurrency(payment.amount)}</td>
                            <td>{payment.paymentMethod}</td>
                            <td>{payment.transactionReference || '—'}</td>
                            <td>{payment.notes || '—'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                <div className="Invoices-page-invoice-totals">
                  <div className="Invoices-page-total-row">
                    <span>Total Amount:</span>
                    <span>{formatCurrency(selectedInvoice.totalAmount)}</span>
                  </div>
                  <div className="Invoices-page-total-row">
                    <span>Paid Amount:</span>
                    <span className="Invoices-page-text-success">{formatCurrency(selectedInvoice.paidAmount)}</span>
                  </div>
                  <div className="Invoices-page-total-row Invoices-page-grand-total">
                    <span>Balance Due:</span>
                    <span className="Invoices-page-text-danger">{formatCurrency(selectedInvoice.balanceAmount)}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="Invoices-page-modal-actions">
              <button
                className="Invoices-page-btn-secondary"
                onClick={() => handleDownloadPdf(selectedInvoice)}
              >
                <Download size={16} style={{ marginRight: '8px' }} />
                Download PDF
              </button>
              <button className="Invoices-page-btn-secondary" onClick={() => handleEditInvoice(selectedInvoice)}>
                Edit Invoice
              </button>
              <button className="Invoices-page-btn-primary" onClick={() => {
                setShowInvoiceModal(false);
                handleRecordPayment(selectedInvoice);
              }}>
                Record Payment
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create/Edit Invoice Modal */}
      {showCreateModal && (
        <div className="Invoices-page-modal-overlay">
          <div className="Invoices-page-modal Invoices-page-modal-xlarge" onClick={e => e.stopPropagation()}>
            <div className="Invoices-page-modal-header">
              <h2>{editMode ? 'Edit Invoice' : 'Create New Invoice'}</h2>
              <button className="Invoices-page-modal-close" onClick={() => setShowCreateModal(false)}>×</button>
            </div>

            <div className="Invoices-page-modal-body">
              <div className="Invoices-page-form">
                <div className="Invoices-page-form-section">
                  <h3>Project Assignment</h3>
                  <div className="Invoices-page-form-grid">
                    <div className="Invoices-page-form-group">
                      <label>Group *</label>
                      <select
                        value={modalGroupName}
                        onChange={handleModalGroupChange}
                        disabled={modalDropdownLoading.groups}
                      >
                        <option value="">
                          {modalDropdownLoading.groups ? 'Loading...' : 'Select Group'}
                        </option>
                        {modalGroups.map((group, index) => (
                          <option key={group.value || index} value={group.value}>
                            {group.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="Invoices-page-form-group">
                      <label>Sub Group</label>
                      <select
                        value={modalSubGroupName}
                        onChange={handleModalSubGroupChange}
                        disabled={!modalGroupName || modalDropdownLoading.subGroups}
                      >
                        <option value="">
                          {modalDropdownLoading.subGroups ? 'Loading...' : 'Select Sub Group'}
                        </option>
                        {modalSubGroups.map((subGroup, index) => (
                          <option key={subGroup.value || index} value={subGroup.value}>
                            {subGroup.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="Invoices-page-form-group">
                      <label>Project *</label>
                      <select
                        value={modalProjectId}
                        onChange={handleModalProjectChange}
                        disabled={!modalSubGroupName || modalDropdownLoading.projects}
                      >
                        <option value="">
                          {modalDropdownLoading.projects ? 'Loading...' : 'Select Project'}
                        </option>
                        {modalProjects.map((project, index) => (
                          <option key={project.id || index} value={project.id}>
                            {project.name}
                          </option>
                        ))}
                      </select>
                    </div>


                  </div>

                  {/* Order Book Section — shown once a project is selected */}
                  {modalProjectId && (
                    <div style={{ marginTop: '14px' }}>
                      {loadingOrderBookItems ? (
                        <div style={{ padding: '12px 16px', background: '#dbeafe', borderRadius: '8px', fontSize: '13px', color: '#1e40af' }}>
                          🔄 Loading order books…
                        </div>
                      ) : orderBooks.length === 0 ? (
                        /* No order books at all for this project */
                        <div style={{ padding: '16px', background: '#fee2e2', border: '2px solid #fecaca', borderRadius: '8px', textAlign: 'center' }}>
                          <div style={{ fontSize: '15px', fontWeight: 600, color: '#991b1b', marginBottom: 4 }}>❌ No Order Book Found</div>
                          <div style={{ fontSize: '13px', color: '#991b1b' }}>No order book is linked to this project yet.</div>
                        </div>
                      ) : (
                        /* One or more order books — show dropdown + items */
                        <div style={{ padding: '16px', background: '#fef3c7', border: '2px solid #fbbf24', borderRadius: '8px' }}>
                          <h4 style={{ marginBottom: '10px', color: '#92400e', fontSize: '15px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                            📦 Select Order Book
                          </h4>

                          {/* Order book dropdown */}
                          <div style={{ marginBottom: '12px' }}>
                            <select
                              value={selectedOrderBookId}
                              onChange={handleOrderBookSelect}
                              style={{ width: '100%', padding: '10px', fontSize: '14px', borderRadius: '6px', border: '1px solid #fbbf24', background: 'white' }}
                            >
                              <option value="">-- Select an Order Book --</option>
                              {orderBooks.map(ob => (
                                <option key={ob.id} value={ob.id}>
                                  {ob.poNumber || ob.orderBookNo} — {ob.orderTitle ? (ob.orderTitle.length > 40 ? ob.orderTitle.substring(0, 40) + '...' : ob.orderTitle) : 'No Title'}
                                </option>
                              ))}
                            </select>
                          </div>

                          {/* Items preview + load button */}
                          {selectedOrderBookId && (
                            loadingOrderBookItems ? (
                              <div style={{ fontSize: '13px', color: '#92400e' }}>🔄 Loading items…</div>
                            ) : orderBookItems.length === 0 ? (
                              <div style={{ fontSize: '13px', color: '#92400e' }}>No items found in this order book.</div>
                            ) : (
                              <>
                                {/* Summary + Load button */}
                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px', flexWrap: 'wrap', gap: 8 }}>
                                  <div style={{ fontSize: '13px', fontWeight: 600, color: '#92400e' }}>
                                    📋 {orderBookItems.length} item{orderBookItems.length !== 1 ? 's' : ''} in order book
                                    <span style={{ fontWeight: 400, color: '#6b7280', marginLeft: 8 }}>
                                      ({orderBookItems.filter(it => Math.max(0, (parseFloat(it.quantity)||0) - (parseFloat(it.invoicedQty)||0)) > 0).length} with remaining qty)
                                    </span>
                                  </div>
                                  <button
                                    className="Invoices-page-btn-primary"
                                    onClick={handleLoadOrderBookItems}
                                    style={{ fontSize: '13px', padding: '6px 14px' }}
                                  >
                                    📥 Load Items into Invoice
                                  </button>
                                </div>

                                {/* Items table */}
                                <div style={{ maxHeight: '180px', overflowY: 'auto', border: '1px solid #fde68a', borderRadius: '6px', background: 'white' }}>
                                  <table style={{ width: '100%', fontSize: '12px', borderCollapse: 'collapse' }}>
                                    <thead>
                                      <tr style={{ background: '#fef3c7', position: 'sticky', top: 0 }}>
                                        <th style={{ padding: '7px 10px', textAlign: 'left', fontWeight: 600, color: '#92400e', borderBottom: '1px solid #fde68a' }}>Item</th>
                                        <th style={{ padding: '7px 10px', textAlign: 'right', fontWeight: 600, color: '#92400e', borderBottom: '1px solid #fde68a' }}>Total Qty</th>
                                        <th style={{ padding: '7px 10px', textAlign: 'right', fontWeight: 600, color: '#92400e', borderBottom: '1px solid #fde68a' }}>Invoiced</th>
                                        <th style={{ padding: '7px 10px', textAlign: 'right', fontWeight: 600, color: '#92400e', borderBottom: '1px solid #fde68a' }}>Remaining</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {orderBookItems.map((item, idx) => {
                                        const total = parseFloat(item.quantity) || 0;
                                        const done  = parseFloat(item.invoicedQty) || 0;
                                        const remaining = Math.max(0, total - done);
                                        return (
                                          <tr key={idx} style={{ borderBottom: '1px solid #fef9c3', background: remaining === 0 ? '#fef9f9' : 'white' }}>
                                            <td style={{ padding: '7px 10px', color: remaining === 0 ? '#9ca3af' : '#111827' }}>
                                              {item.itemName}
                                              {remaining === 0 && <span style={{ marginLeft: 6, fontSize: '10px', color: '#ef4444', fontWeight: 600 }}>FULLY INVOICED</span>}
                                            </td>
                                            <td style={{ padding: '7px 10px', textAlign: 'right', color: '#374151' }}>{total} {item.unit || ''}</td>
                                            <td style={{ padding: '7px 10px', textAlign: 'right', color: '#f59e0b' }}>{done}</td>
                                            <td style={{ padding: '7px 10px', textAlign: 'right', fontWeight: 600, color: remaining > 0 ? '#059669' : '#ef4444' }}>{remaining}</td>
                                          </tr>
                                        );
                                      })}
                                    </tbody>
                                  </table>
                                </div>
                              </>
                            )
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {customerData && (
                  <div className="Invoices-page-form-section">
                    <h3>Customer Information</h3>
                    <div style={{
                      padding: '16px',
                      backgroundColor: '#f0f9ff',
                      border: '1px solid #bae6fd',
                      borderRadius: '8px',
                      fontSize: '14px'
                    }}>
                      <p><strong>Company:</strong> {customerData.companyName}</p>
                      <p><strong>Contact Person:</strong> {customerData.contactPerson}</p>
                      <p><strong>Email:</strong> {customerData.email}</p>
                      <p><strong>Phone:</strong> {customerData.phone}</p>
                      {customerData.gstNumber && <p><strong>GST:</strong> {customerData.gstNumber}</p>}
                    </div>
                  </div>
                )}

                <div className="Invoices-page-form-section">
                  <h3>Invoice Details</h3>
                  <div className="Invoices-page-form-grid">
                    <div className="Invoices-page-form-group">
                      <label>Invoice Date *</label>
                      <input
                        type="date"
                        value={formData.invoiceDate}
                        onChange={(e) => setFormData({ ...formData, invoiceDate: e.target.value })}
                      />
                    </div>
                    <div className="Invoices-page-form-group">
                      <label>Due Date</label>
                      <input
                        type="date"
                        value={formData.dueDate}
                        onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                        min={formData.invoiceDate}
                      />
                    </div>
                  </div>
                </div>

                <div className="Invoices-page-form-section">
                  <div className="Invoices-page-section-header">
                    <h3>Invoice Items *</h3>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      {formData.items.some(it => it.orderBookItemId) && (
                        <span style={{ fontSize: '12px', color: '#059669', fontWeight: 500 }}>📦 Loaded from order book</span>
                      )}
                      <button className="Invoices-page-btn-add" onClick={addItem}>+ Add Item</button>
                    </div>
                  </div>

                  {/* ── Column header row ─────────────────────────── */}
                  <div className="Invoices-page-item-header-row">
                    <span>Description *</span>
                    <span>Unit Type</span>
                    <span>Qty</span>
                    <span>Unit Price *</span>
                    <span>Tax %</span>
                    <span>Line Total</span>
                    <span></span>
                  </div>

                  {formData.items.map((item, index) => (
                    <div key={index} className="Invoices-page-item-row">

                      {/* Col 1 — Description with autocomplete dropdown */}
                      <div className="Invoices-page-ifield" style={{ position: 'relative' }}>
                        <input
                          type="text"
                          value={item.description}
                          onChange={(e) => handleDescriptionChange(index, e.target.value)}
                          onFocus={() => { if (item.description && item.description.length >= 2) handleDescriptionChange(index, item.description); }}
                          placeholder="Item description…"
                          className="Invoices-page-iinput"
                        />
                        {showDropdown[index] && filteredItems[index]?.length > 0 && (
                          <div className="invoice-item-dropdown">
                            {filteredItems[index].map((obItem) => (
                              <div key={obItem.id} onClick={() => selectOrderBookItem(index, obItem)}
                                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f8fafc'}
                                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'white'}
                              >
                                <div style={{ fontWeight: 600, color: '#1e293b', marginBottom: 2 }}>{obItem.itemName}</div>
                                {obItem.specification && <div style={{ fontSize: 12, color: '#64748b', marginBottom: 2 }}>{obItem.specification}</div>}
                                <div style={{ fontSize: 11, color: '#94a3b8' }}>Order: {obItem.orderBookNo} | Qty: {obItem.quantity} {obItem.unit} | ₹{parseFloat(obItem.unitPrice).toFixed(2)}</div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Col 2 — Unit Type */}
                      <div className="Invoices-page-ifield">
                        <UnitTypeDropdown
                          value={item.unitType}
                          onChange={(e) => updateItem(index, 'unitType', e.target.value)}
                          className="Invoices-page-iinput"
                        />
                      </div>

                      {/* Col 3 — Qty with max cap */}
                      <div className="Invoices-page-ifield">
                        <input
                          type="number"
                          value={item.quantity}
                          min={0}
                          max={item.maxQty != null ? item.maxQty : undefined}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            const clamped = item.maxQty != null ? Math.min(val, item.maxQty) : val;
                            updateItem(index, 'quantity', clamped);
                          }}
                          className={`Invoices-page-iinput${item.maxQty != null && item.quantity > item.maxQty ? ' Invoices-page-iinput-error' : ''}`}
                          title={item.maxQty != null ? `Max: ${item.maxQty}` : ''}
                        />
                        {item.maxQty != null && (
                          <span className="Invoices-page-qty-cap">max {item.maxQty}</span>
                        )}
                      </div>

                      {/* Col 4 — Unit Price */}
                      <div className="Invoices-page-ifield">
                        <input
                          type="number"
                          value={item.unitPrice}
                          onChange={(e) => updateItem(index, 'unitPrice', parseFloat(e.target.value))}
                          className="Invoices-page-iinput"
                          placeholder="0.00"
                        />
                      </div>

                      {/* Col 5 — Tax % */}
                      <div className="Invoices-page-ifield">
                        <select
                          value={item.taxPercent}
                          onChange={(e) => updateItem(index, 'taxPercent', parseFloat(e.target.value))}
                          className="Invoices-page-iinput"
                        >
                          <option value="0">0%</option>
                          <option value="5">5%</option>
                          <option value="12">12%</option>
                          <option value="18">18%</option>
                          <option value="28">28%</option>
                        </select>
                      </div>

                      {/* Col 6 — Line Total (read-only) */}
                      <div className="Invoices-page-ifield Invoices-page-ifield-total">
                        {formatCurrency(item.quantity * item.unitPrice * (1 + item.taxPercent / 100))}
                      </div>

                      {/* Col 7 — Remove */}
                      <button
                        className="Invoices-page-btn-remove"
                        onClick={() => removeItem(index)}
                        title="Remove item"
                        style={{ visibility: formData.items.length > 1 ? 'visible' : 'hidden' }}
                      >×</button>

                    </div>
                  ))}

                  <div className="Invoices-page-calculation-summary">
                    <div className="Invoices-page-calc-row">
                      <span>Subtotal:</span>
                      <span>{formatCurrency(calculateInvoice().subtotal)}</span>
                    </div>
                    <div className="Invoices-page-calc-row">
                      <span>Tax Total:</span>
                      <span>{formatCurrency(calculateInvoice().taxTotal)}</span>
                    </div>
                    <div className="Invoices-page-calc-row Invoices-page-calc-grand">
                      <span>Grand Total:</span>
                      <span>{formatCurrency(calculateInvoice().grandTotal)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="Invoices-page-modal-actions">
              <button className="Invoices-page-btn-secondary" onClick={() => handleSaveInvoice('DRAFT')}>
                Save as Draft
              </button>
              <button className="Invoices-page-btn-primary" onClick={() => handleSaveInvoice('SENT')}>
                {editMode ? 'Update Invoice' : 'Create & Send Invoice'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Record Payment Modal */}
      {showPaymentModal && selectedInvoice && (
        <div className="Invoices-page-modal-overlay">
          <div className="Invoices-page-modal" onClick={e => e.stopPropagation()}>
            <div className="Invoices-page-modal-header">
              <h2>Record Payment</h2>
              <button className="Invoices-page-modal-close" onClick={() => setShowPaymentModal(false)}>×</button>
            </div>

            <div className="Invoices-page-modal-body">
              <div style={{
                padding: '16px',
                backgroundColor: '#f8fafc',
                borderRadius: '8px',
                marginBottom: '20px'
              }}>
                <div className="Invoices-page-payment-row">
                  <span>Invoice ID:</span>
                  <strong>{selectedInvoice.invoiceNo}</strong>
                </div>
                <div className="Invoices-page-payment-row">
                  <span>Total Amount:</span>
                  <strong>{formatCurrency(selectedInvoice.totalAmount)}</strong>
                </div>
                <div className="Invoices-page-payment-row">
                  <span>Already Paid:</span>
                  <strong className="Invoices-page-text-success">
                    {formatCurrency(selectedInvoice.paidAmount)}
                  </strong>
                </div>
                <div className="Invoices-page-payment-row">
                  <span>Balance Due:</span>
                  <strong className="Invoices-page-text-danger">
                    {formatCurrency(selectedInvoice.balanceAmount)}
                  </strong>
                </div>
              </div>

              <div className="Invoices-page-form">
                <div className="Invoices-page-form-group">
                  <label>Amount Paid *</label>
                  <input
                    type="number"
                    value={paymentData.amount}
                    onChange={(e) => setPaymentData({ ...paymentData, amount: parseFloat(e.target.value) })}                  
                    max={selectedInvoice.balanceAmount}
                  />
                </div>

                <div className="Invoices-page-form-group">
                  <label>Payment Method *</label>
                  <select
                    value={paymentData.method}
                    onChange={(e) => setPaymentData({ ...paymentData, method: e.target.value })}
                  >
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="UPI">UPI</option>
                    <option value="Cash">Cash</option>
                    <option value="Cheque">Cheque</option>
                    <option value="Credit Card">Credit Card</option>
                  </select>
                </div>

                <div className="Invoices-page-form-group">
                  <label>Notes</label>
                  <textarea
                    value={paymentData.notes}
                    onChange={(e) => setPaymentData({ ...paymentData, notes: e.target.value })}
                    placeholder="Transaction reference, notes, etc."
                    rows="3"
                  />
                </div>

                <div className="Invoices-page-form-group">
                  <label>Transaction Reference</label>
                  <input
                    type="text"
                    value={paymentData.transactionReference}
                    onChange={(e) => setPaymentData({ ...paymentData, transactionReference: e.target.value })}
                    placeholder="Transaction ID, cheque number, etc."
                  />
                </div>
              </div>
            </div>

            <div className="Invoices-page-modal-actions">
              <button className="Invoices-page-btn-secondary" onClick={() => setShowPaymentModal(false)}>
                Cancel
              </button>
              <button className="Invoices-page-btn-primary" onClick={handleSavePayment}>
                Record Payment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InvoicesManagementPage;