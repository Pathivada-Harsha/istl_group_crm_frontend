import React, { useState, useCallback, useRef } from 'react';
import { useAuth } from '../hooks/useAuth';
import '../pages-css/InventoryManagement.css';

// ── Constants ─────────────────────────────────────────────────────────────────
const API = process.env.REACT_APP_API_URL;
const LS_TAB = 'inv_active_tab';

const CATEGORY_COLORS = {
  'Electrical':  { bg: '#eff6ff', color: '#1e40af', border: '#bfdbfe' },
  'Mechanical':  { bg: '#f0fdf4', color: '#166534', border: '#bbf7d0' },
  'Civil':       { bg: '#fef3c7', color: '#92400e', border: '#fde68a' },
  'Consumable':  { bg: '#fdf4ff', color: '#7e22ce', border: '#e9d5ff' },
  'Tool':        { bg: '#fff7ed', color: '#9a3412', border: '#fed7aa' },
  'Other':       { bg: '#f8fafc', color: '#475569', border: '#e2e8f0' },
};

const STOCK_STATUS = {
  IN_STOCK:    { label: 'In Stock',    bg: '#dcfce7', color: '#166534' },
  LOW_STOCK:   { label: 'Low Stock',   bg: '#fef9c3', color: '#854d0e' },
  OUT_OF_STOCK:{ label: 'Out of Stock',bg: '#fee2e2', color: '#991b1b' },
  ON_ORDER:    { label: 'On Order',    bg: '#e0f2fe', color: '#0c4a6e' },
};

const TXN_TYPES = {
  INWARD:       { label: 'Inward',       bg: '#dcfce7', color: '#166534', icon: '↓' },
  OUTWARD:      { label: 'Outward',      bg: '#fee2e2', color: '#991b1b', icon: '↑' },
  TRANSFER:     { label: 'Transfer',     bg: '#e0f2fe', color: '#0c4a6e', icon: '⇄' },
  ADJUSTMENT:   { label: 'Adjustment',   bg: '#fef9c3', color: '#854d0e', icon: '~' },
  RETURN:       { label: 'Return',       bg: '#fdf4ff', color: '#7e22ce', icon: '↩' },
};

const UNITS = ['Nos', 'Kg', 'Ltr', 'Mtr', 'Box', 'Set', 'Roll', 'Sheet', 'Pair', 'Bag'];

// ── Mock data for demo ────────────────────────────────────────────────────────
const MOCK_ITEMS = [
  { id: 1, itemCode: 'EL-001', name: 'Solar Panel 550W Mono', category: 'Electrical', unit: 'Nos', currentQty: 42, minQty: 10, maxQty: 100, unitCost: 18500, projectId: 'PROJ-2026-0015', location: 'Warehouse A', status: 'IN_STOCK', lastUpdated: '2026-05-28' },
  { id: 2, itemCode: 'EL-002', name: 'Inverter 10KW',          category: 'Electrical', unit: 'Nos', currentQty: 6,  minQty: 5,  maxQty: 20,  unitCost: 65000, projectId: 'PROJ-2026-0015', location: 'Warehouse A', status: 'LOW_STOCK',  lastUpdated: '2026-05-29' },
  { id: 3, itemCode: 'EL-003', name: 'AC Cable 6mm²',          category: 'Electrical', unit: 'Mtr', currentQty: 0,  minQty: 50, maxQty: 500, unitCost: 85,    projectId: 'PROJ-2026-0024', location: 'Store B',    status: 'OUT_OF_STOCK',lastUpdated: '2026-05-25' },
  { id: 4, itemCode: 'ME-001', name: 'Module Mounting Clamp',  category: 'Mechanical', unit: 'Set', currentQty: 180,minQty: 50, maxQty: 500, unitCost: 320,   projectId: 'PROJ-2026-0024', location: 'Warehouse A', status: 'IN_STOCK',  lastUpdated: '2026-05-30' },
  { id: 5, itemCode: 'CI-001', name: 'GI Channel 40×40',       category: 'Civil',      unit: 'Mtr', currentQty: 55, minQty: 20, maxQty: 200, unitCost: 410,   projectId: 'PROJ-2026-0033', location: 'Site Store', status: 'IN_STOCK',  lastUpdated: '2026-05-27' },
  { id: 6, itemCode: 'CO-001', name: 'Lugs & Crimping Set',    category: 'Consumable', unit: 'Box', currentQty: 3,  minQty: 5,  maxQty: 30,  unitCost: 750,   projectId: 'PROJ-2026-0033', location: 'Store B',    status: 'LOW_STOCK', lastUpdated: '2026-05-26' },
  { id: 7, itemCode: 'TL-001', name: 'Torque Wrench Set',      category: 'Tool',       unit: 'Set', currentQty: 2,  minQty: 1,  maxQty: 5,   unitCost: 4500,  projectId: 'PROJ-2026-0021', location: 'Tool Room',  status: 'IN_STOCK',  lastUpdated: '2026-05-20' },
  { id: 8, itemCode: 'EL-004', name: 'DC String Cable 4mm²',   category: 'Electrical', unit: 'Mtr', currentQty: 320,minQty: 100,maxQty: 1000,unitCost: 62,    projectId: 'PROJ-2026-0021', location: 'Warehouse A', status: 'IN_STOCK', lastUpdated: '2026-05-28' },
];

const MOCK_TRANSACTIONS = [
  { id: 1, date: '2026-05-30', type: 'INWARD',     itemCode: 'ME-001', itemName: 'Module Mounting Clamp', qty: 100, unit: 'Set',  projectId: 'PROJ-2026-0024', ref: 'PO-2026-00041', note: 'PO delivery batch 2', by: 'Ravi Kumar' },
  { id: 2, date: '2026-05-29', type: 'OUTWARD',    itemCode: 'EL-001', itemName: 'Solar Panel 550W Mono', qty: 20,  unit: 'Nos',  projectId: 'PROJ-2026-0015', ref: 'ISS-002',       note: 'Site installation phase 1', by: 'Arun Sharma' },
  { id: 3, date: '2026-05-29', type: 'ADJUSTMENT', itemCode: 'EL-002', itemName: 'Inverter 10KW',          qty: -1,  unit: 'Nos',  projectId: 'PROJ-2026-0015', ref: 'ADJ-005',       note: 'Physical verification shortfall', by: 'Admin' },
  { id: 4, date: '2026-05-28', type: 'INWARD',     itemCode: 'EL-004', itemName: 'DC String Cable 4mm²',   qty: 200, unit: 'Mtr',  projectId: 'PROJ-2026-0021', ref: 'PO-2026-00038', note: 'Balance delivery',       by: 'Ravi Kumar' },
  { id: 5, date: '2026-05-27', type: 'OUTWARD',    itemCode: 'CI-001', itemName: 'GI Channel 40×40',       qty: 30,  unit: 'Mtr',  projectId: 'PROJ-2026-0033', ref: 'ISS-001',       note: 'Mounting structure erection', by: 'Site Team' },
  { id: 6, date: '2026-05-26', type: 'RETURN',     itemCode: 'CO-001', itemName: 'Lugs & Crimping Set',    qty: 2,   unit: 'Box',  projectId: 'PROJ-2026-0033', ref: 'RET-003',       note: 'Unused returned from site',   by: 'Arun Sharma' },
  { id: 7, date: '2026-05-25', type: 'TRANSFER',   itemCode: 'TL-001', itemName: 'Torque Wrench Set',      qty: 1,   unit: 'Set',  projectId: 'PROJ-2026-0021', ref: 'TRF-001',       note: 'Moved to PROJ-0033 site',     by: 'Admin' },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
function fmt(n) { return Number(n).toLocaleString('en-IN'); }
function fmtCcy(n) { return '₹' + Number(n).toLocaleString('en-IN'); }

// ── Toast ─────────────────────────────────────────────────────────────────────
function useToast() {
  const [toasts, setToasts] = useState([]);
  const add = useCallback((msg, type = 'success') => {
    const id = Date.now() + Math.random();
    setToasts(p => [...p, { id, msg, type }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 3500);
  }, []);
  return { toasts, add };
}
function ToastStack({ toasts }) {
  if (!toasts.length) return null;
  return (
    <div className="inv-toast-stack">
      {toasts.map(t => (
        <div key={t.id} className={`inv-toast inv-toast--${t.type}`}>
          <span>{t.type === 'success' ? '✓' : '!'}</span>
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}

// ── Add Item Modal ────────────────────────────────────────────────────────────
function AddItemModal({ open, onClose, onSave }) {
  const [form, setForm] = useState({
    itemCode: '', name: '', category: 'Electrical', unit: 'Nos',
    currentQty: '', minQty: '', maxQty: '', unitCost: '',
    projectId: '', location: '', note: ''
  });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  if (!open) return null;
  return (
    <div className="inv-overlay" onClick={onClose}>
      <div className="inv-modal" onClick={e => e.stopPropagation()}>
        <div className="inv-modal-header">
          <div>
            <h3 className="inv-modal-title">Add New Item</h3>
            <p className="inv-modal-sub">Register a new inventory item</p>
          </div>
          <button className="inv-icon-btn" onClick={onClose}>✕</button>
        </div>

        <div className="inv-modal-body">
          <div className="inv-form-grid">
            <div className="inv-field">
              <label className="inv-label">Item Code <span className="inv-req">*</span></label>
              <input className="inv-input" placeholder="EL-001" value={form.itemCode} onChange={e => set('itemCode', e.target.value)} />
            </div>
            <div className="inv-field inv-field--full">
              <label className="inv-label">Item Name <span className="inv-req">*</span></label>
              <input className="inv-input" placeholder="e.g. Solar Panel 550W Mono" value={form.name} onChange={e => set('name', e.target.value)} />
            </div>
            <div className="inv-field">
              <label className="inv-label">Category</label>
              <select className="inv-select" value={form.category} onChange={e => set('category', e.target.value)}>
                {Object.keys(CATEGORY_COLORS).map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="inv-field">
              <label className="inv-label">Unit</label>
              <select className="inv-select" value={form.unit} onChange={e => set('unit', e.target.value)}>
                {UNITS.map(u => <option key={u}>{u}</option>)}
              </select>
            </div>
            <div className="inv-field">
              <label className="inv-label">Opening Qty</label>
              <input className="inv-input" type="number" min="0" placeholder="0" value={form.currentQty} onChange={e => set('currentQty', e.target.value)} />
            </div>
            <div className="inv-field">
              <label className="inv-label">Unit Cost (₹)</label>
              <input className="inv-input" type="number" min="0" placeholder="0.00" value={form.unitCost} onChange={e => set('unitCost', e.target.value)} />
            </div>
            <div className="inv-field">
              <label className="inv-label">Min Qty (Reorder Level)</label>
              <input className="inv-input" type="number" min="0" placeholder="0" value={form.minQty} onChange={e => set('minQty', e.target.value)} />
            </div>
            <div className="inv-field">
              <label className="inv-label">Max Qty</label>
              <input className="inv-input" type="number" min="0" placeholder="0" value={form.maxQty} onChange={e => set('maxQty', e.target.value)} />
            </div>
            <div className="inv-field">
              <label className="inv-label">Project ID</label>
              <input className="inv-input" placeholder="PROJ-2026-XXXX" value={form.projectId} onChange={e => set('projectId', e.target.value)} />
            </div>
            <div className="inv-field">
              <label className="inv-label">Location / Store</label>
              <input className="inv-input" placeholder="Warehouse A" value={form.location} onChange={e => set('location', e.target.value)} />
            </div>
            <div className="inv-field inv-field--full">
              <label className="inv-label">Note</label>
              <textarea className="inv-textarea" rows={2} placeholder="Optional description..." value={form.note} onChange={e => set('note', e.target.value)} />
            </div>
          </div>
        </div>

        <div className="inv-modal-actions">
          <button className="inv-btn inv-btn--ghost" onClick={onClose}>Cancel</button>
          <button className="inv-btn inv-btn--primary" onClick={() => { onSave(form); onClose(); }}>
            Add Item
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Transaction Modal ─────────────────────────────────────────────────────────
function TransactionModal({ open, onClose, onSave, items }) {
  const [form, setForm] = useState({
    type: 'INWARD', itemId: '', qty: '', ref: '', note: '', projectId: '', date: new Date().toISOString().slice(0, 10)
  });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const selectedItem = items.find(i => String(i.id) === String(form.itemId));

  if (!open) return null;
  return (
    <div className="inv-overlay" onClick={onClose}>
      <div className="inv-modal inv-modal--sm" onClick={e => e.stopPropagation()}>
        <div className="inv-modal-header">
          <div>
            <h3 className="inv-modal-title">Record Transaction</h3>
            <p className="inv-modal-sub">Inward, outward, or adjustment</p>
          </div>
          <button className="inv-icon-btn" onClick={onClose}>✕</button>
        </div>

        <div className="inv-modal-body">
          {/* Transaction type pills */}
          <div className="inv-field">
            <label className="inv-label">Transaction Type</label>
            <div className="inv-type-pills">
              {Object.entries(TXN_TYPES).map(([k, v]) => (
                <button key={k}
                  className={`inv-type-pill${form.type === k ? ' active' : ''}`}
                  style={form.type === k ? { background: v.bg, color: v.color, borderColor: v.color + '88' } : {}}
                  onClick={() => set('type', k)}>
                  <span className="inv-type-icon">{v.icon}</span> {v.label}
                </button>
              ))}
            </div>
          </div>

          <div className="inv-form-grid">
            <div className="inv-field inv-field--full">
              <label className="inv-label">Item <span className="inv-req">*</span></label>
              <select className="inv-select" value={form.itemId} onChange={e => set('itemId', e.target.value)}>
                <option value="">Select item…</option>
                {items.map(i => <option key={i.id} value={i.id}>{i.itemCode} — {i.name}</option>)}
              </select>
              {selectedItem && (
                <div className="inv-item-hint">
                  Current stock: <strong>{fmt(selectedItem.currentQty)} {selectedItem.unit}</strong>
                  &nbsp;·&nbsp;Location: {selectedItem.location}
                </div>
              )}
            </div>
            <div className="inv-field">
              <label className="inv-label">Quantity <span className="inv-req">*</span></label>
              <input className="inv-input" type="number" min="0.01" step="0.01" placeholder="0" value={form.qty} onChange={e => set('qty', e.target.value)} />
            </div>
            <div className="inv-field">
              <label className="inv-label">Date</label>
              <input className="inv-input" type="date" value={form.date} onChange={e => set('date', e.target.value)} />
            </div>
            <div className="inv-field">
              <label className="inv-label">Reference (PO / GRN / Issue No.)</label>
              <input className="inv-input" placeholder="e.g. PO-2026-00041" value={form.ref} onChange={e => set('ref', e.target.value)} />
            </div>
            <div className="inv-field">
              <label className="inv-label">Project ID</label>
              <input className="inv-input" placeholder="PROJ-2026-XXXX" value={form.projectId} onChange={e => set('projectId', e.target.value)} />
            </div>
            <div className="inv-field inv-field--full">
              <label className="inv-label">Note</label>
              <textarea className="inv-textarea" rows={2} placeholder="Reason / details…" value={form.note} onChange={e => set('note', e.target.value)} />
            </div>
          </div>
        </div>

        <div className="inv-modal-actions">
          <button className="inv-btn inv-btn--ghost" onClick={onClose}>Cancel</button>
          <button className="inv-btn inv-btn--primary"
            disabled={!form.itemId || !form.qty}
            onClick={() => { onSave(form); onClose(); }}>
            Save Transaction
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Item Detail Drawer ────────────────────────────────────────────────────────
function ItemDrawer({ item, transactions, onClose }) {
  if (!item) return null;
  const catMeta  = CATEGORY_COLORS[item.category] || CATEGORY_COLORS.Other;
  const statMeta = STOCK_STATUS[item.status] || STOCK_STATUS.IN_STOCK;
  const itemTxns = transactions.filter(t => t.itemCode === item.itemCode);
  const totalValue = item.currentQty * item.unitCost;

  return (
    <div className="inv-drawer-backdrop" onClick={onClose}>
      <div className="inv-drawer" onClick={e => e.stopPropagation()}>
        <div className="inv-drawer-header">
          <div>
            <div className="inv-drawer-code">{item.itemCode}</div>
            <h2 className="inv-drawer-name">{item.name}</h2>
            <div className="inv-drawer-badges">
              <span className="inv-cat-badge" style={{ background: catMeta.bg, color: catMeta.color, borderColor: catMeta.border }}>{item.category}</span>
              <span className="inv-status-badge" style={{ background: statMeta.bg, color: statMeta.color }}>{statMeta.label}</span>
            </div>
          </div>
          <button className="inv-icon-btn" onClick={onClose}>✕</button>
        </div>

        {/* KPI strip */}
        <div className="inv-drawer-kpis">
          <div className="inv-drawer-kpi">
            <div className="inv-drawer-kpi-val">{fmt(item.currentQty)} <span className="inv-drawer-kpi-unit">{item.unit}</span></div>
            <div className="inv-drawer-kpi-lbl">Current Stock</div>
          </div>
          <div className="inv-drawer-kpi">
            <div className="inv-drawer-kpi-val">{fmtCcy(item.unitCost)}</div>
            <div className="inv-drawer-kpi-lbl">Unit Cost</div>
          </div>
          <div className="inv-drawer-kpi">
            <div className="inv-drawer-kpi-val">{fmtCcy(totalValue)}</div>
            <div className="inv-drawer-kpi-lbl">Total Value</div>
          </div>
          <div className="inv-drawer-kpi">
            <div className="inv-drawer-kpi-val">{fmt(item.minQty)} – {fmt(item.maxQty)}</div>
            <div className="inv-drawer-kpi-lbl">Min – Max Qty</div>
          </div>
        </div>

        {/* Stock progress bar */}
        <div className="inv-drawer-section">
          <div className="inv-drawer-section-title">Stock Level</div>
          <div className="inv-stock-bar-wrap">
            <div className="inv-stock-bar-track">
              <div className="inv-stock-bar-min" style={{ left: `${(item.minQty / item.maxQty) * 100}%` }} title={`Min: ${item.minQty}`} />
              <div className="inv-stock-bar-fill"
                style={{
                  width: `${Math.min(100, (item.currentQty / item.maxQty) * 100)}%`,
                  background: item.status === 'OUT_OF_STOCK' ? '#ef4444' : item.status === 'LOW_STOCK' ? '#f59e0b' : '#10b981'
                }}
              />
            </div>
            <div className="inv-stock-bar-labels">
              <span>0</span><span>Reorder: {item.minQty}</span><span>Max: {item.maxQty}</span>
            </div>
          </div>
        </div>

        {/* Details */}
        <div className="inv-drawer-section">
          <div className="inv-drawer-section-title">Details</div>
          <table className="inv-detail-table">
            <tbody>
              <tr><td>Project</td><td>{item.projectId}</td></tr>
              <tr><td>Location</td><td>{item.location}</td></tr>
              <tr><td>Last Updated</td><td>{item.lastUpdated}</td></tr>
            </tbody>
          </table>
        </div>

        {/* Transaction history */}
        <div className="inv-drawer-section">
          <div className="inv-drawer-section-title">Recent Transactions ({itemTxns.length})</div>
          {itemTxns.length === 0 ? (
            <p className="inv-empty-hint">No transactions yet.</p>
          ) : (
            <div className="inv-txn-list">
              {itemTxns.map(t => {
                const tm = TXN_TYPES[t.type];
                return (
                  <div key={t.id} className="inv-txn-row">
                    <span className="inv-txn-type" style={{ background: tm.bg, color: tm.color }}>{tm.icon} {tm.label}</span>
                    <div className="inv-txn-info">
                      <span className="inv-txn-qty">{t.qty > 0 ? '+' : ''}{fmt(t.qty)} {t.unit}</span>
                      <span className="inv-txn-ref">{t.ref}</span>
                    </div>
                    <span className="inv-txn-date">{t.date}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── KPI Cards ─────────────────────────────────────────────────────────────────
function KpiCards({ items }) {
  const totalItems   = items.length;
  const totalValue   = items.reduce((s, i) => s + i.currentQty * i.unitCost, 0);
  const lowStock     = items.filter(i => i.status === 'LOW_STOCK').length;
  const outOfStock   = items.filter(i => i.status === 'OUT_OF_STOCK').length;

  const cards = [
    { icon: '📦', label: 'Total Items',    value: totalItems,       sub: 'registered',                       color: '#1e40af', bg: '#eff6ff' },
    { icon: '💰', label: 'Total Value',    value: fmtCcy(totalValue), sub: 'at current cost',                color: '#065f46', bg: '#ecfdf5' },
    { icon: '⚠️', label: 'Low Stock',      value: lowStock,          sub: 'need reorder',                   color: '#92400e', bg: '#fffbeb', alert: lowStock > 0 },
    { icon: '🔴', label: 'Out of Stock',   value: outOfStock,        sub: 'items unavailable',              color: '#991b1b', bg: '#fef2f2', alert: outOfStock > 0 },
  ];

  return (
    <div className="inv-kpi-grid">
      {cards.map((c, i) => (
        <div key={i} className={`inv-kpi-card${c.alert ? ' inv-kpi-card--alert' : ''}`}
          style={{ borderLeftColor: c.color }}>
          <div className="inv-kpi-icon" style={{ background: c.bg, fontSize: 22 }}>{c.icon}</div>
          <div className="inv-kpi-content">
            <div className="inv-kpi-value">{c.value}</div>
            <div className="inv-kpi-label">{c.label}</div>
            <div className="inv-kpi-sub">{c.sub}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Items Tab ─────────────────────────────────────────────────────────────────
function ItemsTab({ items, transactions, onAddItem, onTransaction, canCreate, canEdit }) {
  const [search, setSearch]       = useState('');
  const [catFilter, setCatFilter] = useState('');
  const [statusFilter, setStatus] = useState('');
  const [projFilter, setProj]     = useState('');
  const [selectedItem, setItem]   = useState(null);

  const projects = [...new Set(items.map(i => i.projectId).filter(Boolean))].sort();

  const filtered = items.filter(i => {
    const q = search.toLowerCase();
    return (
      (!q || i.name.toLowerCase().includes(q) || i.itemCode.toLowerCase().includes(q)) &&
      (!catFilter || i.category === catFilter) &&
      (!statusFilter || i.status === statusFilter) &&
      (!projFilter || i.projectId === projFilter)
    );
  });

  return (
    <>
      {/* KPIs */}
      <KpiCards items={items} />

      {/* Action bar */}
      <div className="inv-action-bar">
        <div className="inv-search-filters">
          <div className="inv-search-wrap">
            <span className="inv-search-icon">🔍</span>
            <input className="inv-search" placeholder="Search by item name or code…"
              value={search} onChange={e => setSearch(e.target.value)} />
            {search && <button className="inv-search-clear" onClick={() => setSearch('')}>✕</button>}
          </div>
          <select className="inv-filter-select" value={catFilter} onChange={e => setCatFilter(e.target.value)}>
            <option value="">All Categories</option>
            {Object.keys(CATEGORY_COLORS).map(c => <option key={c}>{c}</option>)}
          </select>
          <select className="inv-filter-select" value={statusFilter} onChange={e => setStatus(e.target.value)}>
            <option value="">All Status</option>
            {Object.entries(STOCK_STATUS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
          <select className="inv-filter-select" value={projFilter} onChange={e => setProj(e.target.value)}>
            <option value="">All Projects</option>
            {projects.map(p => <option key={p}>{p}</option>)}
          </select>
          {(search || catFilter || statusFilter || projFilter) && (
            <button className="inv-btn inv-btn--ghost inv-btn--sm"
              onClick={() => { setSearch(''); setCatFilter(''); setStatus(''); setProj(''); }}>
              ✕ Clear
            </button>
          )}
        </div>
        <div className="inv-action-right">
          {canCreate && (
            <button className="inv-btn inv-btn--secondary inv-btn--icon" onClick={onTransaction}>
              ⇄ Record Transaction
            </button>
          )}
          {canCreate && (
            <button className="inv-btn inv-btn--primary inv-btn--icon" onClick={onAddItem}>
              + Add Item
            </button>
          )}
        </div>
      </div>

      {/* Count */}
      <div className="inv-result-count">
        Showing <strong>{filtered.length}</strong> of {items.length} items
      </div>

      {/* Table */}
      <div className="inv-table-container">
        <table className="inv-table">
          <thead>
            <tr>
              <th>Code</th>
              <th>Item Name</th>
              <th>Category</th>
              <th style={{ textAlign: 'right' }}>Qty</th>
              <th>Unit</th>
              <th style={{ textAlign: 'right' }}>Unit Cost</th>
              <th style={{ textAlign: 'right' }}>Total Value</th>
              <th>Project</th>
              <th>Location</th>
              <th>Status</th>
              <th>Updated</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={12} className="inv-empty-cell">
                  <div className="inv-empty">
                    <span className="inv-empty-icon">📋</span>
                    <p>{search || catFilter || statusFilter ? 'No items match your filters.' : 'No items added yet. Click "+ Add Item" to begin.'}</p>
                  </div>
                </td>
              </tr>
            ) : filtered.map(item => {
              const cm = CATEGORY_COLORS[item.category] || CATEGORY_COLORS.Other;
              const sm = STOCK_STATUS[item.status] || STOCK_STATUS.IN_STOCK;
              return (
                <tr key={item.id} className="inv-table-row" onClick={() => setItem(item)}>
                  <td className="inv-code-cell">{item.itemCode}</td>
                  <td className="inv-name-cell">{item.name}</td>
                  <td>
                    <span className="inv-cat-badge" style={{ background: cm.bg, color: cm.color, borderColor: cm.border }}>
                      {item.category}
                    </span>
                  </td>
                  <td style={{ textAlign: 'right', fontWeight: 600, color: item.status === 'OUT_OF_STOCK' ? '#ef4444' : item.status === 'LOW_STOCK' ? '#f59e0b' : '#0f172a' }}>
                    {fmt(item.currentQty)}
                  </td>
                  <td className="inv-muted">{item.unit}</td>
                  <td style={{ textAlign: 'right' }}>{fmtCcy(item.unitCost)}</td>
                  <td style={{ textAlign: 'right', fontWeight: 600 }}>{fmtCcy(item.currentQty * item.unitCost)}</td>
                  <td className="inv-muted">{item.projectId || '—'}</td>
                  <td className="inv-muted">{item.location}</td>
                  <td>
                    <span className="inv-status-badge" style={{ background: sm.bg, color: sm.color }}>
                      {sm.label}
                    </span>
                  </td>
                  <td className="inv-muted">{item.lastUpdated}</td>
                  <td>
                    <button className="inv-view-btn" onClick={e => { e.stopPropagation(); setItem(item); }}>
                      View
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Drawer */}
      {selectedItem && (
        <ItemDrawer item={selectedItem} transactions={transactions} onClose={() => setItem(null)} />
      )}
    </>
  );
}

// ── Transactions Tab ──────────────────────────────────────────────────────────
function TransactionsTab({ transactions, onTransaction, canCreate }) {
  const [search, setSearch]   = useState('');
  const [typeFilter, setType] = useState('');
  const [projFilter, setProj] = useState('');

  const projects = [...new Set(transactions.map(t => t.projectId).filter(Boolean))].sort();

  const filtered = transactions.filter(t => {
    const q = search.toLowerCase();
    return (
      (!q || t.itemName.toLowerCase().includes(q) || t.itemCode.toLowerCase().includes(q) || (t.ref || '').toLowerCase().includes(q)) &&
      (!typeFilter || t.type === typeFilter) &&
      (!projFilter || t.projectId === projFilter)
    );
  });

  return (
    <>
      <div className="inv-action-bar">
        <div className="inv-search-filters">
          <div className="inv-search-wrap">
            <span className="inv-search-icon">🔍</span>
            <input className="inv-search" placeholder="Search by item, code or reference…"
              value={search} onChange={e => setSearch(e.target.value)} />
            {search && <button className="inv-search-clear" onClick={() => setSearch('')}>✕</button>}
          </div>
          <select className="inv-filter-select" value={typeFilter} onChange={e => setType(e.target.value)}>
            <option value="">All Types</option>
            {Object.entries(TXN_TYPES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
          <select className="inv-filter-select" value={projFilter} onChange={e => setProj(e.target.value)}>
            <option value="">All Projects</option>
            {projects.map(p => <option key={p}>{p}</option>)}
          </select>
          {(search || typeFilter || projFilter) && (
            <button className="inv-btn inv-btn--ghost inv-btn--sm"
              onClick={() => { setSearch(''); setType(''); setProj(''); }}>
              ✕ Clear
            </button>
          )}
        </div>
        {canCreate && (
          <button className="inv-btn inv-btn--primary inv-btn--icon" onClick={onTransaction}>
            ⇄ Record Transaction
          </button>
        )}
      </div>

      <div className="inv-result-count">
        Showing <strong>{filtered.length}</strong> of {transactions.length} transactions
      </div>

      <div className="inv-table-container">
        <table className="inv-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Type</th>
              <th>Item Code</th>
              <th>Item Name</th>
              <th style={{ textAlign: 'right' }}>Qty</th>
              <th>Unit</th>
              <th>Reference</th>
              <th>Project</th>
              <th>Note</th>
              <th>By</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={10} className="inv-empty-cell">
                <div className="inv-empty"><span className="inv-empty-icon">📋</span><p>No transactions found.</p></div>
              </td></tr>
            ) : filtered.map(t => {
              const tm = TXN_TYPES[t.type];
              return (
                <tr key={t.id} className="inv-table-row">
                  <td className="inv-muted">{t.date}</td>
                  <td>
                    <span className="inv-txn-type" style={{ background: tm.bg, color: tm.color }}>
                      {tm.icon} {tm.label}
                    </span>
                  </td>
                  <td className="inv-code-cell">{t.itemCode}</td>
                  <td className="inv-name-cell">{t.itemName}</td>
                  <td style={{ textAlign: 'right', fontWeight: 600,
                    color: ['OUTWARD','TRANSFER'].includes(t.type) ? '#ef4444' : t.qty < 0 ? '#ef4444' : '#166534' }}>
                    {t.qty > 0 && !['OUTWARD','TRANSFER'].includes(t.type) ? '+' : ''}{fmt(t.qty)}
                  </td>
                  <td className="inv-muted">{t.unit}</td>
                  <td className="inv-code-cell">{t.ref || '—'}</td>
                  <td className="inv-muted">{t.projectId || '—'}</td>
                  <td className="inv-note-cell" title={t.note}>{t.note}</td>
                  <td className="inv-muted">{t.by}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ── Low Stock Alert Tab ───────────────────────────────────────────────────────
function AlertsTab({ items, onTransaction, canCreate }) {
  const alerts = items.filter(i => i.status === 'LOW_STOCK' || i.status === 'OUT_OF_STOCK')
    .sort((a, b) => (a.status === 'OUT_OF_STOCK' ? -1 : 1));

  return (
    <div className="inv-alerts-wrap">
      {alerts.length === 0 ? (
        <div className="inv-alerts-ok">
          <span style={{ fontSize: 48 }}>✅</span>
          <h3>All items are well-stocked</h3>
          <p>No low stock or out-of-stock items at this time.</p>
        </div>
      ) : (
        <>
          <div className="inv-alert-header">
            <span className="inv-alert-count inv-alert-count--danger">
              🔴 {items.filter(i => i.status === 'OUT_OF_STOCK').length} Out of Stock
            </span>
            <span className="inv-alert-count inv-alert-count--warning">
              ⚠️ {items.filter(i => i.status === 'LOW_STOCK').length} Low Stock
            </span>
          </div>
          <div className="inv-alerts-list">
            {alerts.map(item => {
              const sm = STOCK_STATUS[item.status];
              const pct = item.maxQty > 0 ? Math.round((item.currentQty / item.maxQty) * 100) : 0;
              return (
                <div key={item.id} className={`inv-alert-card inv-alert-card--${item.status === 'OUT_OF_STOCK' ? 'danger' : 'warning'}`}>
                  <div className="inv-alert-card-top">
                    <div>
                      <span className="inv-alert-code">{item.itemCode}</span>
                      <span className="inv-alert-name">{item.name}</span>
                    </div>
                    <span className="inv-status-badge" style={{ background: sm.bg, color: sm.color }}>{sm.label}</span>
                  </div>
                  <div className="inv-alert-progress-wrap">
                    <div className="inv-alert-progress-track">
                      <div className="inv-alert-progress-fill"
                        style={{
                          width: `${pct}%`,
                          background: item.status === 'OUT_OF_STOCK' ? '#ef4444' : '#f59e0b'
                        }}
                      />
                    </div>
                    <span className="inv-alert-pct">{pct}%</span>
                  </div>
                  <div className="inv-alert-card-bottom">
                    <span>Current: <strong>{fmt(item.currentQty)} {item.unit}</strong></span>
                    <span>Reorder at: <strong>{fmt(item.minQty)} {item.unit}</strong></span>
                    <span>Project: <strong>{item.projectId || '—'}</strong></span>
                    <span>Location: <strong>{item.location}</strong></span>
                    {canCreate && (
                      <button className="inv-btn inv-btn--primary inv-btn--xs" onClick={onTransaction}>
                        + Raise Inward
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function InventoryManagementPage() {
  const { user, pagePermissions } = useAuth();
  const toast = useToast();

  const invPerms  = pagePermissions?.INVENTORY || [];
  const isAccounts = user?.role && user.role.toUpperCase().startsWith('ACCOUNTS_');
  const isAdmin    = ['ADMIN', 'SUPERADMIN'].includes((user?.role || '').toUpperCase());
  const canView    = invPerms.includes('VIEW')   || isAdmin || isAccounts;
  const canCreate  = invPerms.includes('CREATE') || isAdmin;
  const canEdit    = invPerms.includes('EDIT')   || isAdmin;

  const [activeTab, setActiveTab] = useState(() => localStorage.getItem(LS_TAB) || 'items');
  const switchTab = t => { setActiveTab(t); localStorage.setItem(LS_TAB, t); };

  const [items,       setItems]       = useState(MOCK_ITEMS);
  const [transactions,setTransactions]= useState(MOCK_TRANSACTIONS);
  const [addOpen,     setAddOpen]     = useState(false);
  const [txnOpen,     setTxnOpen]     = useState(false);

  const alertCount = items.filter(i => i.status === 'LOW_STOCK' || i.status === 'OUT_OF_STOCK').length;

  const handleAddItem = (form) => {
    const newItem = {
      id: items.length + 1,
      itemCode:   form.itemCode,
      name:       form.name,
      category:   form.category,
      unit:       form.unit,
      currentQty: Number(form.currentQty) || 0,
      minQty:     Number(form.minQty) || 0,
      maxQty:     Number(form.maxQty) || 0,
      unitCost:   Number(form.unitCost) || 0,
      projectId:  form.projectId,
      location:   form.location || 'Warehouse A',
      status:     Number(form.currentQty) === 0 ? 'OUT_OF_STOCK'
                : Number(form.currentQty) <= Number(form.minQty) ? 'LOW_STOCK'
                : 'IN_STOCK',
      lastUpdated: new Date().toISOString().slice(0, 10),
    };
    setItems(p => [newItem, ...p]);
    toast.add(`"${form.name}" added to inventory`);
  };

  const handleTransaction = (form) => {
    const item = items.find(i => String(i.id) === String(form.itemId));
    if (!item) return;
    const qty = Number(form.qty);
    const delta = ['OUTWARD', 'TRANSFER'].includes(form.type) ? -qty : form.type === 'ADJUSTMENT' && qty < 0 ? qty : qty;
    const newQty = Math.max(0, item.currentQty + delta);
    const newStatus = newQty === 0 ? 'OUT_OF_STOCK' : newQty <= item.minQty ? 'LOW_STOCK' : 'IN_STOCK';

    setItems(p => p.map(i => i.id === item.id ? { ...i, currentQty: newQty, status: newStatus, lastUpdated: form.date } : i));
    setTransactions(p => [{
      id: p.length + 1, date: form.date, type: form.type,
      itemCode: item.itemCode, itemName: item.name,
      qty: delta, unit: item.unit,
      projectId: form.projectId, ref: form.ref, note: form.note, by: user?.name || 'Admin'
    }, ...p]);
    toast.add(`Transaction recorded for "${item.name}"`);
  };

  return (
    <div className="inv-page">
      <ToastStack toasts={toast.toasts} />

      {/* ── Sticky top ──────────────────────────────────────────────────────── */}
      <div className="inv-sticky-top">
        <div className="inv-page-header">
          <div className="inv-header-left">
            <div className="inv-header-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <rect x="2" y="7" width="20" height="14" rx="2" stroke="currentColor" strokeWidth="2"/>
                <path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2" stroke="currentColor" strokeWidth="2"/>
                <line x1="12" y1="12" x2="12" y2="16" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                <line x1="10" y1="14" x2="14" y2="14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
            <div>
              <h1 className="inv-title">Inventory Management</h1>
              <p className="inv-subtitle">Track stock levels, movements, and reorder alerts across all project sites.</p>
            </div>
          </div>
          <div className="inv-header-right">
            {alertCount > 0 && (
              <button className="inv-alert-pill" onClick={() => switchTab('alerts')}>
                ⚠️ {alertCount} alert{alertCount !== 1 ? 's' : ''}
              </button>
            )}
            {canCreate && (
              <button className="inv-btn inv-btn--secondary" onClick={() => setTxnOpen(true)}>
                ⇄ Transaction
              </button>
            )}
            {canCreate && (
              <button className="inv-btn inv-btn--primary" onClick={() => setAddOpen(true)}>
                + Add Item
              </button>
            )}
          </div>
        </div>

        {/* Tabs */}
        <div className="inv-tabs">
          {[
            { k: 'items',        label: 'Items',        count: items.length },
            { k: 'transactions', label: 'Transactions', count: transactions.length },
            { k: 'alerts',       label: 'Alerts',       count: alertCount, warn: alertCount > 0 },
          ].map(t => (
            <button key={t.k}
              className={`inv-tab ${activeTab === t.k ? 'active' : ''}`}
              onClick={() => switchTab(t.k)}>
              {t.label}
              <span className={`inv-tab-count${t.warn ? ' inv-tab-count--warn' : ''}`}>{t.count}</span>
            </button>
          ))}
        </div>
      </div>

      {/* ── Scroll area ─────────────────────────────────────────────────────── */}
      <div className="inv-scroll-area">
        {activeTab === 'items' && (
          <ItemsTab items={items} transactions={transactions}
            onAddItem={() => setAddOpen(true)} onTransaction={() => setTxnOpen(true)}
            canCreate={canCreate} canEdit={canEdit} />
        )}
        {activeTab === 'transactions' && (
          <TransactionsTab transactions={transactions}
            onTransaction={() => setTxnOpen(true)} canCreate={canCreate} />
        )}
        {activeTab === 'alerts' && (
          <AlertsTab items={items} onTransaction={() => setTxnOpen(true)} canCreate={canCreate} />
        )}
      </div>

      {/* Modals */}
      <AddItemModal     open={addOpen} onClose={() => setAddOpen(false)} onSave={handleAddItem} />
      <TransactionModal open={txnOpen} onClose={() => setTxnOpen(false)} onSave={handleTransaction} items={items} />
    </div>
  );
}